<?php
    session_start();

    include("admin/config.php");
    include("admin/lang.php");
    include("admin/all-langs.php");

    if(!isset($_SESSION["admin-language"]))
    {
        $_SESSION["admin-language"] = 'EN';
    }

    // Registering default language in the cookies.
    // ---------------- Changing the admin language ----------------
    if(isset($_POST["lang-default-frontend"]))
    {
        $_SESSION["lang-default-frontend"] = $_POST["lang-default-frontend"];
        $_SESSION['lang-code'] =  $_POST['lang-code'];

        echo 'ok';
    }

    // Function for getting CV data from the database for a specific language.
    function defaultDate($language, $bdd)
    {
        // getting the date from database, which is in the json format.
        $rqt = $bdd -> prepare('SELECT * FROM cv WHERE cv_language=?');
        $rqt -> execute([$language]);

        $data = [];
        while($dateDB = $rqt -> fetch(PDO::FETCH_ASSOC))
        {
            array_push($data, $dateDB);
        }
        return $data;
    }

    if($_POST['condition'] == 'lang-Display')
    {
        // getting the date from database, which is in the json format.
        $rqt = $bdd -> query('SELECT cv_language FROM cv');

        $data = [];
        while($dateDB = $rqt -> fetch(PDO::FETCH_ASSOC))
        {
            array_push($data, $dateDB);
        }

        echo json_encode($data);
    }

    if($_POST['condition'] == 'charger')
    {
        echo json_encode(defaultDate($_POST['lang'], $bdd));
    }

    if($_POST['condition'] == 'saving-lang-in-session')
    {
        $_SESSION['lang-default-frontend'] =  $_POST['lang'];
        $_SESSION['lang-code'] =  $nativeNamesCodes[$_POST['lang']];
    }
?>