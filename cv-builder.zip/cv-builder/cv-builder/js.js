// Fonction permettant de rechercher un élément html par id.
function byId(id)
{
    return document.getElementById(id);
}

// Function to save data in localStorage.
function Enrg(cls, vls)
{
    window.localStorage.setItem(cls, vls);
}

// Function to get data from localStorage.
function Recup(cls)
{
    return window.localStorage.getItem(cls);
}

// ------------------- Displaying social networks. -------------------
var SN =
{
    "Facebook" : "fab fa-facebook-square text-primary ml-3 h3",
    "Blog" : "fas fa-blog text-danger ml-3 h3",
    "Twitter" : "fab fa-twitter-square text-primary ml-3 h3",
    "Linkedin" : "fab fa-linkedin text-primary ml-3 h3",
    "Viadeo" : "fab fa-viadeo-square text-danger ml-3 h3",
    "Instagram" : "fab fa-instagram text-danger ml-3 h3",
    "Snapshat" : "fab fa-snapchat-square text-warning ml-3 h3",
    "Google+" : "fab fa-google-plus-square text-danger ml-3 h3",
    "Pinterest" : "fab fa-pinterest-square text-danger ml-3 h3",
    "Tumblr" : "fab fa-tumblr-square text-info ml-3 h3",
    "Youtube" : "fab fa-youtube text-danger ml-3 h3",
    "Share" : "fas fa-share-alt text-info ml-3 h3",
    "Internet" : "fab fa-internet-explorer text-primary ml-3 h3",
}

// Fonction pour smooth scrolling
$(document).ready(
    function()
    {
        $("a").on("click", function(event)
        {
            if(this.hash !== "")
            {
                event.preventDefault();
                var hashVal = this.hash;
                $("html, body").animate(
                    { scrollTop: $(hashVal).offset().top },
                    800,
                    function()
                    {
                        window.location.hash = hashVal;
                    }
                );
            }
        });
    }
);

// Registering default language in the cookies and also showing the website with default language.
$(document).ready(function() {
    if(Recup('lang-default-frontend') == undefined)
    {
        if(isoLangs[navigator.language] == undefined) {
            Enrg("lang-default-frontend", 'Français');
        }
        else {
            Enrg("lang-default-frontend", isoLangs[navigator.language]['nativeName']);
        }

        byId('lang').value = Recup('lang-default-frontend');

        // Request AJAX to save the default language in the PHP Sessions
        var data = new FormData();
        data.append("condition", 'saving-lang-in-session');
        data.append("lang", Recup('lang-default-frontend'));
        // data.append("lang-code", navigator.language);

        // XMLHttpRequest() resquest.
        if(window.XMLHttpRequest)
        {
            var xHttp = new XMLHttpRequest();
        }
        else
        {
            var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xHttp.open("POST", "php.php", true);
        xHttp.send(data);

        // Defining lang attribute of the lang element of the front page
        $('html').attr('lang',navigator.language);
    }
});


// Function to display all the languages titles present in the database.
function displayFrontendLang(condition)
{
    var data = new FormData();
    data.append("condition", condition);

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            var frontLang = '';
            for(x in JSON.parse(this.responseText))
            {
                frontLang += '<option value="'+JSON.parse(this.responseText)[x]['cv_language']+'">'+JSON.parse(this.responseText)[x]['cv_language']+'</option>';
            }

            byId('lang').innerHTML = frontLang;
            byId('lang').value = Recup('lang-default-frontend');
        }
    }
}

$(document).ready( function() {
    displayFrontendLang('lang-Display');
});

// Function for changing frontend language
function changeFrontendLang(lang)
{
    var data = new FormData();
    data.append("lang-default-frontend", lang);
    data.append("lang-code", nativeNameCodes[lang]);

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            if(this.responseText == "ok")
            {
                Enrg("lang-default-frontend", lang);
                location.reload();
            }
        }
    }
}

// Converting html element from string to DOM
function convertToHTML(htmlElem) {
    var textElem = document.getElementsByTagName(htmlElem);

    var x = 0;
    for(x=0; x<=textElem.length-1; x++) {
        textElem[x].innerHTML = textElem[x].innerHTML.replaceAll('&lt;', '<').replaceAll('&gt;', '>');
    }

}

convertToHTML('p');