<?php
session_start();

include("config.php");
include("lang.php");

// Script for connected user.
if(isset($_SESSION['nom']) AND isset($_SESSION['email']))
{
	header('Location: cv-admin.php');
}

include("head.php");
?>

<body>
	<main id="main" class="main">
		<header id="hdr" class="hdr">
			<nav id="nav" class="nav">
			</nav>
		</header>

		<section id="sctn" class="sctn">
			<?php
			// I add PHP script for the user that use this CMS for the first time, this means if there is no user registered in database.
			// First script is for user that has an account registered in database.
			$forRegisUser ='
			<article id="artlConn" class="artlConn">
				<div class="container border border-1 my-4 py-4">
					<div class="row" >
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							<h3 class="text-center text-uppercase">'.$tabText['login'].'</h3>
						</div>
					</div>

					<div class="row" >
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 px-sm-5">
							<form method="post" id="formConn" class="container">
								<div class="row mb-3">
									<fieldset class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 border border-1 py-3">
										<legend class="col-xl-3 col-lg-3 col-md-3 col-sm-5 col-10 text-center">'.$tabText['login-data'].'</legend>

										<div class="form-group mx-sm-5" >
											<input type="email" name="email" id="email" class="form-control mb-3 email" placeholder="'.$tabText['email'].' *" required autofocus/>

											<div class="input-group mb-3">
												<input type="password" name="mdp" id="mdp" class="form-control chmpTxt" placeholder="'.$tabText['password'].' *" required/>
												<div class="input-group-append">
												<button class="btn btn-outline-secondary btn-sm" title="'.$tabText['password-visibility'].'" type="button" data-count=0 id="btn3Visible" onclick="pssdVisibility(event, \'mdp\', \'btn3Visible\')"><i class="fas fa-eye-slash"></i></button>
												</div>
											</div>
										</div>
									</fieldset>
								</div>

								<div class="row" >
									<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
										<button type="submit" id="btn" class="btn btn-secondary btn-sm" onclick="userConn(event)">'.$tabText['login'].'</button>
										<p id="msgConn"></p>
									</div>
								</div>
							</form>
						</div>
					</div>

					<div class="row" >
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
							<span id="btnReg" class="all-buttons">'.$tabText['lost-password'].'</span>
						</div>
					</div>
				</div>

				<p id="msg"></p>
			</article>

			<article id="artlMdp" class="artlMdp">
				<div class="container border border-1 my-4 py-4">
					<div class="row" >
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 px-sm-5 mb-5">
							<h3 class="text-center text-uppercase">'.$tabText['password-recovery'].'</h3>
							<p>'.$tabText['password-recovery-helptext'].'</p>
						</div>
					</div>

					<div class="row" >
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 px-sm-5">
							<form method="post" id="formPswd" class="container">
								<div class="row mb-3">
									<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
										<div class="form-group mx-sm-5">
											<input type="email" name="email" id="email" class="form-control mb-3 chmpTxt" placeholder="'.$tabText['email'].' *" required/>
										</div>
									</div>
								</div>

								<div class="row" >
									<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
										<button type="submit" id="btn" class="btn btn-secondary btn-sm" onclick="pswdRecover(event)">'.$tabText['send'].'</button>
										<p id="msgPswd"></p>
									</div>
								</div>
							</form>
						</div>
					</div>

					<div class="row" >
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
							<span id="btnConn" class="all-buttons">'.$tabText['login'].'</span>
						</div>
					</div>
				</div>

				<p id="msg"></p>
			</article>';

			// Second script is for user that doesn't have any account registered in database.
			$forUnRegisUser ='
			<article id="artlReg" class="">
				<div class="container border border-1 my-4 py-4">
					<div class="row" >
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
							<h3 class="text-center text-uppercase" >'.$tabText['registration'].'</h3>
						</div>
					</div>

					<div class="row" >
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 px-sm-5">
							<form method="post" id="formIns" class="container" >
								<div class="row mb-3">
									<fieldset class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 border border-1 py-3">
										<legend class="col-xl-3 col-lg-4 col-md-5 col-sm-7 col-9 text-center">'.$tabText['user-registration'].'</legend>

										<div class="form-group mx-sm-5" >
											<input type="text" name="nom" id="nom" class="form-control mb-3 chmpTxt" placeholder="'.$tabText['name'].' *" required autofocus/>
											<input type="email" name="email" id="email" class="form-control mb-3 chmpTxt" placeholder="'.$tabText['email'].' *" required/>
											<input type="email" name="emailRetype" id="emailRetype" class="form-control mb-3 chmpTxt" placeholder="'.$tabText['retype-email'].' *" required/>

											<div class="input-group mb-3">
												<input type="password" name="mdp" id="psdRegis" class="form-control chmpTxt" placeholder="'.$tabText['password'].' *" required/>
												<div class="input-group-append">
												<button class="btn btn-outline-secondary btn-sm" title="'.$tabText['password-visibility'].'" type="button" data-count=0 id="btn1Visible" onclick="pssdVisibility(event, \'psdRegis\', \'btn1Visible\')"><i class="fas fa-eye-slash"></i></button>
												</div>
											</div>

											<div class="input-group mb-3">
												<input type="password" name="mdpRetype" id="psdRegisRpt" class="form-control chmpTxt" placeholder="'.$tabText['retype-password'].' *" required/>
												<div class="input-group-append">
												<button class="btn btn-outline-secondary btn-sm" title="'.$tabText['password-visibility'].'" type="button" data-count=0 id="btn2Visible" onclick="pssdVisibility(event, \'psdRegisRpt\', \'btn2Visible\')"><i class="fas fa-eye-slash"></i></button>
												</div>
											</div>
										</div>
									</fieldset>
								</div>

								<div class="row" >
									<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
										<button type="submit" id="btn" class="btn btn-secondary btn-sm" onclick="userReg(event)">'.$tabText['register'].'</button>
										<p id="msgIns"></p>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>

				<p id="msg"></p>
			</article>';

            $rqt = $bdd -> query('SELECT * FROM login');
			$rqtFtch = $rqt -> fetchAll(PDO::FETCH_ASSOC);

			if(!empty($rqtFtch))
			{
				echo $forRegisUser;
			}
			elseif(empty($rqtFtch))
			{
				echo $forUnRegisUser;
			}
			?>

		</section>
    </main>

<?php
include("foot.php");
?>