<?php
    /* ***** function to upload files. *****
    * This function has parameters:
    * $arrayFile : 1st parameter is the name of the $_FILES array that has the images sent from Javascript.
    * $fileSizeLimit : 2nd paramater is about the file size limitation in mega bytes(Mb).
    * $arrayFileFormat : 3rd parameter is about the authorized file formats.
    * $arrayMsg : 4th parameter is an array of the alert messages, where
    *   first alert message in array is when the user sent no files,
    *   second alert message is about the file size limitation,
    *   the thirst alert message in array is about the file format,
    *   the fourth alert message in array is an error message when the file is not uploaded.
    * $tempFolder : 5th parameter is the temporary folder where the image uploaded will be stored before creating the thumbnails or resized photos.
    *   This paramter can also be false when you uploade files other than images.
    * $destiFolder : 6th parameter is the destination folder where the photo resized or any other file(s) will be uploaded.
    * $imageWidth : 7th parameter is the width of the image. If the 5th parameter is marked as false in case of uploading other files, the 7th will be false too.
    * $delete : 8th parameter will delete all the previousaly uploaded images or files in the $destiFolder folder, if it is marked as true.
    */

    function imgUploading($arrayFile, $fileSizeLimit, $arrayFileFormat, $arrayMsg, $tempFolder, $destiFolder, $imageWidth, $delete)
    {
        $clsImg = key($arrayFile);

        /* // If no file is sent, we display a message to the visitor.
        if($arrayFile[$clsImg]["error"] > 0)
        {
            die($arrayMsg[0]);
        } */

        if(count($arrayFile) < 2 )
        {
            // Files temporary names.
            $nomTemp = $arrayFile[$clsImg]["tmp_name"];

            // files exact names.
            $nomExact = $arrayFile[$clsImg]["name"];

            // Files sizes.
            $sizeKB = filesize($nomTemp);
            $sizeMB = round($sizeKB/1000000, 2, PHP_ROUND_HALF_UP); // Conversion d'octets en Mo

            // Exact file source.
            $chemin = dirname($nomTemp);
            $chemin = $chemin."\\".$nomExact;

            // Extension
            $extenF = pathinfo($chemin)["extension"];

            // Generating files names in PHP.
            $nomGenere = "";
            do
            {
                $nomGenere = basename($nomTemp).rand().rand()."TIME".date("YmdHi");
            }
            while(file_exists("img\img-profil\\".$nomGenere.".".$extenF));

            // Validating files sizes sent by users
            if($sizeMB > $fileSizeLimit)
            {
                exit($arrayMsg[1]);
            }

            // Validating files formats sent by users
            if(!in_array($extenF, $arrayFileFormat))
            {
                exit($arrayMsg[2]);
            }

            // Script for checking where the user is sending the photos or any other files.
            if($tempFolder !=  false)
            {
                $dossier = $tempFolder;
            }
            else
            {
                $dossier = $destiFolder;
                $imageWidth = false;
            }

            // Files uploading
            if(move_uploaded_file($nomTemp, $dossier.$nomGenere.".".$extenF))
            {
                // Delete old files before the new one is uploaded if the $delete parameter is marked as true.
                if($delete == true)
                {
                    $tabDirectory = scandir($destiFolder);
                    $tabDirectory = array_diff($tabDirectory, ["..", "."]);

                    foreach($tabDirectory as $vls)
                    {
                        unlink($destiFolder.$vls);
                    }
                }

                // Making the thumnail in case of image and deleting the image saved in $tempFolder folder if the $tempFolder parameter is not marked as false.
                if($tempFolder !=  false && $imageWidth != false)
                {
                    // Creating thumbnails in img/img-profil directory.
                    miniature($tempFolder.$nomGenere.".".$extenF, $destiFolder, $imageWidth, $extenF);

                    // Deleting the image created temporary in img/img-temp/ directory.
                    unlink($tempFolder.$nomGenere.".".$extenF);
                }

                // If file is uploaded successfully, we return an array.
                $results =
                [
                    "exact-name" => pathinfo(pathinfo($arrayFile[$clsImg]["tmp_name"])["dirname"]."\\".$nomExact)["filename"],
                    "generated-name" => $nomGenere,
                    "extension" => $extenF,
                    "size" =>  $sizeMB,
                    "source-folder" => $destiFolder,
                ];

                return $results;
            }
            else
            {
                exit($arrayMsg[3]);
            }
        }
        else
        {
            /* // Files temporary names.
            $nomTemp = [];
            foreach($arrayFile as $cls => $vls)
            {
                array_push($nomTemp, $arrayFile[$cls]["tmp_name"]);
            }

            // files exact names.
            $nomExact = [];
            foreach($arrayFile as $cls => $vls)
            {
                array_push($nomExact, $arrayFile[$cls]["name"]);
            }

            // Files sizes.
            $tailleF = [];
            foreach($nomTemp as $vls)
            {
                $Ko = filesize($vls);
                $Mo = round($Ko/1000000, 2, PHP_ROUND_HALF_UP); // Conversion d'octets en Mo
                array_push($tailleF, $Mo);
            }

            // Exact file source.
            $cheminExact = [];
            foreach($arrayFile as $cls => $vls)
            {
                $chemin = dirname($nomTemp[$cls]);
                array_push($cheminExact, $chemin."\\".$nomExact[$cls]);
            }

            // Extension
            $extenF = [];
            foreach($cheminExact as $vls)
            {
                array_push( $extenF, pathinfo($vls)["extension"]);
            }

            // Generating files names in PHP.
            $nomGenere = [];
            foreach($nomTemp as $cls => $vls)
            {
                $genere = "";
                do
                {
                    $genere = basename($vls).rand().rand()."_TIME-".date("siH_dmY");
                }
                while(file_exists("img\\".$genere.".".$extenF[$cls]) OR in_array($genere, $nomGenere));

                array_push($nomGenere, $genere);
            }

            // Validating files sizes sent by users
            foreach($tailleF as $vls)
            {
                if($vls > $fileSizeLimit)
                {
                    exit($arrayMsg[1]);
                }
            }

            // Validating files formats sent by users
            foreach($extenF as $vls)
            {
                if(!in_array($vls, $arrayFileFormat))
                {
                    exit($arrayMsg[2]);
                }
            }

            // Files uploading
            $succes = "";
            foreach($nomTemp as $cls => $vls)
            {
                if(move_uploaded_file($vls, $tempFolder.$nomGenere[$cls].".".$extenF[$cls]))
                {
                    $succes = "OK";
                }
                else
                {
                    exit($arrayMsg[3]);
                }
            }

            $srcTab = [];
            $srcTab["src"] = "img/img-profil/".$nomGenere.".".$extenF;

            $data = json_encode($srcTab); */

            /* // Creating thumbnails
            foreach($nomGenere as $cls => $vls)
            {
                miniature("img_temp/".$nomGenere[$cls].".".$extenF[$cls], "thumb", 500);
                miniature("img_temp/".$nomGenere[$cls].".".$extenF[$cls], "img", 1980);
            }

            // Delete all the images created temporary in img_temps
            for($i=0; $i<count($nomGenere); $i++)
            {
                unlink("img_temp/".$nomGenere[$i].".".$extenF[$i]);
            }

            if($succes == "OK")
            {
                return true;
            } */
        }
    }