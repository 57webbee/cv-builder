<?php
    /*
        Langue : French
        Introduction :
            Cette fonction vous permet de générer une vignette au format de votre choix. Nous pouvons lui envoyer un format PNG, JPG ou GIF et lui demander de générer une vignette au format PNG, JPG ou GIF.

        - miniature(dosSrc, dosDest, largeurDest, typeImgDest, nav, pixelate)
            - dosSrc(String) : est le chemin de l'image des sources. Exemple : $dossierSrc = "dossier/sous_dossier/image.png";
            - dosDest(String) : est le chemin du dossier, dans lequel la vignette sera enregistrée. Exemple : $dossierDest = "dossier/sous_dossier";
            - largeurDest(Number) : est la largeur de la vignette. La hauteur de l'image de destination est calculée par la fonction en regardant la largeur donnée et la hauteur exacte de l'image source.
            - typeImgDest(string) : prend le format(png, jpg ou gif) de la vignette à générer.  Par défaut il à la valeur de "jpg".
            - nav(Boolean) :  permet d'afficher l'image générée, dans le navigateur. Par défaut il est à false.
            - pixelate(Boolean)  : est utile pour générer une png. ça applique le filtre de pixalisation qui permet de reduire la taille d'une vignette. Par défaut il est à false.

        Note : Pour télécharger une image avec cette function, veuillez vérifier ces parametres de votre PHP(php.ini).
            - memory_limit : -1(pas de limite)
            - post_max_size : 64M
            - upload_max_filesize : 64M
    */

    function miniature($dosSrc, $dosDest, $largeurDest, $typeImgDest="jpg", $nav = false, $pixelate = false)
    {
        // Préparation de l'entête et de la ressource.
        $header = "";
        $ext = pathinfo($dosSrc)["extension"];
        if($ext == "png")
        {
            $header = "image/png";
            $src = imagecreatefrompng($dosSrc);
        }
        else if($ext == "jpg")
        {
            $header = "image/jpeg";
            $src = imagecreatefromjpeg($dosSrc);
        }
        else if($ext == "gif")
        {
            $header = "image/gif";
            $src = imagecreatefromgif($dosSrc);
        }
        header('Content-Type: '.$header);

        // Préparer la largeur et la hauteur d'une image.
        $lSrc = imagesx($src);
        $hSrc = imagesy($src);
        $hDest = 0;
        $lPercent = ($largeurDest/imagesx($src))*100;
        $hDest = ($lPercent*imagesy($src))/100;
        /* if($lSrc < $largeurDest)
        {
            $lSrc = ($largeurDest-$lSrc)+$lSrc;
        } */

        $dest = imagecreatetruecolor($largeurDest, $hDest);

        // Génération de la miniature.
        imagecopyresampled($dest, $src, 0, 0, 0, 0, $largeurDest, $hDest, $lSrc, $hSrc);

        // Afficher et enregistrer l'image en JPEG, PNG ou GIF.
        $nomF = pathinfo($dosSrc)["filename"].".".$typeImgDest;
        if($typeImgDest == "png")
        {
            // Ajoutez un filtre pour réduire la taille de l'image.
            if($pixelate == true)
            {
                imagefilter($dest, IMG_FILTER_PIXELATE, 2);
            }

            // Voir dans le navigateur.
            if($nav == true)
            {
                imagepng($dest);
            }

            // Enregistrer dans le fichier.
            imagepng($dest, $dosDest."/".$nomF, 9, PNG_FILTER_SUB);
        }
        else if($typeImgDest == "jpg")
        {
            // Voir dans le navigateur.
            if($nav == true)
            {
                imagejpeg($dest,  NULL, 50);
            }

            // Enregistrer dans le fichier.
            imagejpeg($dest, $dosDest."/".$nomF, 50);
        }
        else if($typeImgDest == "gif")
        {
            // Voir dans le navigateur.
            if($nav == true)
            {
                imagegif($dest);
            }

            // Enregistrer dans le fichier.
            imagegif($dest, $dosDest."/".$nomF);
        }

        imagedestroy($src);
        imagedestroy($dest);
    }
?>