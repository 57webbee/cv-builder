
// Fonction permettant de rechercher un élément html par id.
function byId(id)
{
    return document.getElementById(id);
}
// Fonction permettant de rechercher un élément html par id.
function refreshPage()
{
    location.reload();
}

// ------------------- Displaying social networks. -------------------
var SN =
{
    "Facebook" : "fab fa-facebook-square text-primary ml-3 h3",
    "Blog" : "fas fa-blog text-danger ml-3 h3",
    "Twitter" : "fab fa-twitter-square text-primary ml-3 h3",
    "Linkedin" : "fab fa-linkedin text-primary ml-3 h3",
    "Viadeo" : "fab fa-viadeo-square text-danger ml-3 h3",
    "Instagram" : "fab fa-instagram text-danger ml-3 h3",
    "Snapshat" : "fab fa-snapchat-square text-warning ml-3 h3",
    "Google+" : "fab fa-google-plus-square text-danger ml-3 h3",
    "Pinterest" : "fab fa-pinterest-square text-danger ml-3 h3",
    "Tumblr" : "fab fa-tumblr-square text-info ml-3 h3",
    "Youtube" : "fab fa-youtube text-danger ml-3 h3",
    "Share" : "fas fa-share-alt text-info ml-3 h3",
    "Internet" : "fab fa-internet-explorer text-primary ml-3 h3",
}

// --------------------------------------------- index.php ---------------------------------------------
// --------------------------------------------- ********* ---------------------------------------------

// To display and hide the configuration.
$(document).ready(function()
{
    $("#btn-config").click(function(){
        $("#details-config").slideToggle();
    });
});

// Script to hide the connection form and show registration one.
$("#btnReg").on(
    "click",
    function()
    {
        $("#artlConn").toggle("slow");
        $("#artlMdp").toggle("slow");
    }
);

// Script to show the connection form and hide the registration one.
$("#btnConn").on(
    "click",
    function()
    {
        $("#artlMdp").toggle("slow");
        $("#artlConn").toggle("slow");
    }
);

// To make visible/invisible the user password input field.
function pssdVisibility(event, elem1, elem2)
{
    event.preventDefault();

    if(byId(elem2).getAttribute('data-count') == 0)
    {
        byId(elem1).type = "text";
        byId(elem2).setAttribute('data-count', 1);
        byId(elem2).innerHTML = '<i class="far fa-eye"></i>';
    }
    else
    {
        byId(elem1).type = "password";
        byId(elem2).setAttribute('data-count', 0);
        byId(elem2).innerHTML = '<i class="fas fa-eye-slash"></i>';
    }
}

// Ajax for registering a user.
function userReg(event)
{
    event.preventDefault();

    var data = new FormData(byId("formIns"));
    data.append("ins", "ins-user");

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            if(this.responseText == "done")
            {
                byId("msgIns").innerHTML = tabText['registered-wait'];

                window.setInterval(
                    function() { location.reload(); },
                    2000
                );
            }
            else
            {
                byId("msgIns").innerHTML=this.responseText;
            }
        }
    }
}

// Ajax for user connection
function userConn(event)
{
    event.preventDefault();

    var data = new FormData(byId("formConn"));
    data.append("conn", "conn-user");

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            if(this.responseText == "done")
            {
                location.reload();
            }
            else
            {
                byId("msgConn").innerHTML=this.responseText;
            }
        }
    }
}

// Ajax for password recovery: Preparing mail et code.
function pswdRecover(event)
{
    event.preventDefault();

    var data = new FormData(byId("formPswd"));
    data.append("pswd", "password-recovery");

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            if(this.responseText == "done")
            {
                byId("msgPswd").innerHTML=tabText['will-receive-mail'];
                byId("formPswd").reset();
            }
            else
            {
                byId("msgPswd").innerHTML=this.responseText;
            }
        }
    }
}

// Ajax for password recovery: Registering new password.
function pswdSave(event)
{
    event.preventDefault();

    var data = new FormData(byId("form"));
    data.append("pswd", "registering-new-password");

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            if(this.responseText == "done")
            {
                byId("msgPswd").innerHTML=tabText['pwd-updated'];
                byId("form").reset();
            }
            else
            {
                byId("msgPswd").innerHTML=this.responseText;
            }
        }
    }
}

// --------------------------------------------- cv-admin.php ---------------------------------------------
// --------------------------------------------- ************ ---------------------------------------------

// Registering default language in the cookies.
if(Recup('adminLang') == undefined)
{
    Enrg("adminLang", 'EN');
}

// Function to select language <select> value.
function displayAdminLang()
{
    byId('admin-languages').value = Recup('lang-default');
}

// Function for changing admin language
function changeAdminLang(lang)
{
    var data = new FormData();
    data.append("admin-language", lang);

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            if(this.responseText == "ok")
            {
                Enrg("adminLang", lang);
                location.reload();
            }
        }
    }
}

// function for counting the elements of an object in js.
/* var ctElem = 0;
function countObjElem(obj)
{
    for(x in obj)
    {
        ctElem += 1;
    }

    return ctElem;
} */

// Function to save data in localStorage.
function Enrg(cls, vls)
{
    window.localStorage.setItem(cls, vls);
}

// Function to get data from localStorage.
function Recup(cls)
{
    return window.localStorage.getItem(cls);
}

// Function to logout the user.
function funcBtn(event, purpose)
{
    event.preventDefault();

    var data = new FormData();
    data.append("purpose", purpose);

    if(purpose == "delete-image")
    {
        data.append("language", Recup("lang-default"));
        data.append("src", byId("profil-img").src);
    }

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            if(this.responseText == "disconnect")
            {
                location.reload();
            }
            else
            {
                displayData(Recup("lang-default"));
            }
        }
    }
}

// Converting html element from string to DOM
function convertToHTML (htmlElem) {
    var textElem = $(htmlElem);

    var x = 0;
    for(x=0; x<=textElem.length-1; x++) {
        textElem[x].innerHTML = textElem[x].innerHTML.replaceAll('&lt;', '<').replaceAll('&gt;', '>');
    }
}

// In order to apear the name of the file selected.
$(".custom-file-input").on(
    "change",
    function()
    {
        var fileName = $(this).val().split("\\").pop();
        $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
    }
);

// Script to hide or display an html element.
function slideAnim(id1, id2)
{
    $("#"+id1).toggle();
    $("#"+id2).toggle();
}

// Modify language by the user.
/* function langModify(e)
{
    Enrg("lang-default", e.target.value);
    displayData(Recup("lang-default"));
} */
function langModify(lang)
{
    Enrg("lang-default", lang);
    displayData(Recup("lang-default"));
    location.reload();
}

var langNav = navigator.language;
var langName = isoLangs; // isoLangs is the object present in all-langs.js file, containing all the languages informations.

//window.localStorage.removeItem("lang-default");
function langs()
{
    var data = new FormData();
    data.append("choice-lang-default", "to-choice-lang-default");

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            var langDB = JSON.parse(this.responseText);

            if(langName[langNav] == undefined) {
                var lngName = 'Français';
            }
            else {
                var lngName = langName[langNav].nativeName;
            }

            // Defining a language by default.
            if(Recup("lang-default") == undefined || Recup("lang-default") == null)
            {
                if(langDB.includes(lngName))
                {
                    Enrg("lang-default", lngName);
                }
                else if(langDB.includes("English"))
                {
                    Enrg("lang-default", "English");
                }
                else
                {
                    Enrg("lang-default", langDB[0]);
                }
            }

            // Script to display all the languages.
            var langOption = "";
            for(x in langDB)
            {
                if(langDB[x] == Recup("lang-default"))
                {
                    langOption += '<option value="'+langDB[x]+'" selected>'+langDB[x]+'</option>';
                }
                else
                {
                    langOption += '<option value="'+langDB[x]+'" >'+langDB[x]+'</option>';
                }
            }
            byId("languages").innerHTML = langOption;
            byId("languages").value = Recup('lang-default');
        }
    }
}

// Function to add all the languages present in the all-langs.js file, in <select> element for "Add language" portion.
function displayLangs()
{
    // Script to display all the languages.
    var langOption = '<option value="'+tabText['select-lang']+'" disabled selected>'+tabText['select-lang']+'</option>';
    for(x in langName)
    {
        langOption += '<option value="'+langName[x].nativeName+'">'+langName[x].nativeName+'</option>';
    }

    byId("add-Language").innerHTML = langOption;
}

function newLanguage(event)
{
    event.preventDefault();

    if(byId("add-Language").value == byId("add-Language").children[0].value)
    {
        byId('msg-lang').innerHTML = tabText['select-lang'];
        event.preventDefault();
        return;
    }

    var data = new FormData(byId("form-new-lang"));
    data.append("new-language", "add-new-language");

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            var tab = JSON.parse(this.responseText);

            if(tab['message'] == "done")
            {
                // Now we display all the languages from the language list once the askded language has been deleted.
                var langOptionEmpty = '<option value="'+tabText["select-lang"]+'" disabled="" selected="true">'+tabText["select-lang"]+'</option>';

                var langOptionAll = '';
                for(x in tab) {
                    if(tab[x] != 'done') {
                        langOptionAll += '<option value="'+tab[x]+'">'+tab[x]+'</option>';
                    }
                }

                byId('delete-Language').innerHTML = langOptionEmpty+langOptionAll;

                // Now we perform the remaining jobs which are eracing the form, displaying the alert message and lanching the js to erace "message container" after some interval.
                var myVar;
                clearTimeout(myVar);

                byId("msg-lang").innerHTML = tabText['lang-added'];
                byId('add-Language').value = tabText['select-lang'];
                langs();

                myVar = setTimeout(function(){
                    byId("msg-lang").innerHTML = '';
                }, 5000);
            }
            else
            {
                byId("msg-lang").innerHTML = this.responseText;
            }
        }
    }
}

function deleteLanguage(event)
{
    event.preventDefault();

    if(byId("delete-Language").value == byId("delete-Language").children[0].value)
    {
        byId('msg-lang-delete').innerHTML = tabText['select-lang'];
        event.preventDefault();
        return;
    }

    var data = new FormData(byId("form-delete-lang"));
    data.append("delete-language", "delete-this-language");
    data.append("current-language", byId("delete-Language").value);

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            var tab = JSON.parse(this.responseText);

            if(tab['message'] == "done")
            {
                // Now we display all the languages from the language list once the askded language has been deleted.
                var langOptionEmpty = '<option value="'+tabText["select-lang"]+'" disabled="" selected="true">'+tabText["select-lang"]+'</option>';

                var langOptionAll = '';
                for(x in tab) {
                    if(tab[x] != 'done') {
                        langOptionAll += '<option value="'+tab[x]+'">'+tab[x]+'</option>';
                    }
                }

                byId('delete-Language').innerHTML = langOptionEmpty+langOptionAll;

                // Now we perform the remaining jobs which are eracing the form, displaying the alert message and lanching the js to erace "message container" after some interval.
                var myVar;
                clearTimeout(myVar);

                byId("msg-lang-delete").innerHTML = tabText['lang-is-deleted'];
                byId('delete-Language').value = tabText['select-lang'];

                myVar = setTimeout(function(){
                    byId("msg-lang-delete").innerHTML = '';
                }, 5000);
            }
            else
            {
                byId("msg-lang-delete").innerHTML = this.responseText;
            }
        }
    }
}

// Displaying all the generated fields.
function newOrDeleteField(purpose, id)
{
    // FormData() used to add new fields.
    if(purpose == event)
    {
        purpose.preventDefault();
        var data = new FormData(byId(id));
        data.append("purpose-field", "event");
    }

    // FormData() used for the rests.
    else
    {
        var data = new FormData();
        data.append("purpose-field", purpose);
    }

    data.append("language", Recup("lang-default"));

    if(id != "all")
    {
        data.append("id", id);
    }

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            if(id == "all")
            {
                var tab = JSON.parse(this.responseText);

                var ct = 0;
                var fieldOption = '';
                var generatedField = "";
                var optSelected = "";

                for(cls in tab)
                {
                    // Script for making a variable for selected <option> element.
                    if(ct == ((Object.keys(tab).length)-1))
                    {
                        optSelected = "selected";
                    }

                    // Script for creating the position <option> of new fields.
                    if(ct >= 0)
                    {
                        if(ct == 0)
                        {
                            fieldOption += '<option value="'+cls+'0" >'+tabText['bofore']+' '+tab[cls]["title"]+'</option>';
                            fieldOption += '<option value="'+cls+'" '+optSelected+'>'+tabText['after']+' '+tab[cls]["title"]+'</option>';
                        }
                        else
                        {
                            fieldOption += '<option value="'+cls+'" '+optSelected+'>'+tabText['after']+' '+tab[cls]["title"]+'</option>';
                        }

                        ct += 1;

                    }

                    var field = "";
                    var fieldEdit = "";
                    var delTitle = tabText['delete'];

                    /* ---------- exp_field ---------- */
                    if(tab[cls]["type"] == "exp_field")
                    {
                        // Making the exp_field data
                        var btnSupp = '<i class="fas fa-times fa-sm btn-outline-secondary all-buttons float-right" title="'+tabText['del-this-field']+'" data-toggle="modal" data-target="#'+cls+'myModal"></i>';

                        var modalTitle = '<div class="modal-header"><h4 class="modal-title">'+tabText['warning']+'</h4><button type="button" class="close" data-dismiss="modal">&times;</button></div>';
                        var modalText = '<div class="modal-body">'+tabText['really-delete']+'</div>';
                        var modalBtn = '<div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal"  onclick="deleteElem(\''+cls+'field\'); deleteElem(\''+cls+'fieldEdit\'); newOrDeleteField(\'delete-a-generated-field\', '+cls+')">'+tabText['yes']+'</button><button type="button" class="btn btn-secondary" data-dismiss="modal">'+tabText['No']+'</button></div>';

                        var modalDiv = '<div class="modal fade" id="'+cls+'myModal"><div class="modal-dialog modal-dialog-centered"><div class="modal-content">'+modalTitle+modalText+modalBtn+'</div></div></div>';

                        var title = '<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"><h4 id="'+cls+'title" class="text-center">'+tab[cls]["title"]+btnSupp+'</h4> </div>';
                        var menuText = '<p><strong>'+tabText['menu-text']+' </strong><span id="'+cls+'menuText">'+tab[cls]["menu-text"]+'</span></p>';

                        var allProjects = "";
                        for(clsAllP in tab[cls]["all-skills"])
                        {
                            var sousTab = tab[cls]["all-skills"];

                            allProjects += '<div class="row mb-3"><div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 '+cls+'-imageContainer"><img id="'+cls+'image'+clsAllP+'" src="'+tab[cls]["img"]+'" alt="" width="15px"/><span class="ml-sm-2 ml-1"><strong id="'+cls+'skillName'+clsAllP+'">'+sousTab[clsAllP]["skill-name"]+'</strong></span></div><div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ml-sm-4"><span id="'+cls+'skillDetails'+clsAllP+'" class="">'+sousTab[clsAllP]["skill-details"]+'</span></div></div>';
                        }

                        var btnEdit = '<div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center"><i class="all-buttons fas fa-edit fa-sm btn btn-outline-info" title="'+tabText['edit-this-field']+'" onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\')"></i></div>';

                        var container = '<div class="container"><div class="row"><div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12" id="'+cls+'all-skills'+'">'+allProjects+'</div>'+btnEdit+'</div></div>';

                        field = '<div id="'+cls+'field" class="row bg-light shadow-sm border border-1 mb-3 p-3">'+title+menuText+container+modalDiv+'</div>';

                        // Making the exp_field-Edit data
                        var menuTextEdit = '<div class="input-group mb-2"><div class="input-group-prepend"><span class="input-group-text">'+tabText['menu-text']+'</span></div><input type="text" class="form-control" name="menuText" id="'+cls+'menuTextEdit" value="'+tab[cls]["menu-text"]+'" placeholder="'+tabText['skills']+'"/></div>';
                        var titleEdit = '<div class="form-groupe"><input id="'+cls+'titleEdit" type="text" class="mb-2 form-control text-uppercase" name="title" value="'+tab[cls]["title"]+'" placeholder="'+tabText['skills']+'" /></div>';
                        var imgEidt = '<div class="overflow-hidden custom-file custom-select-sm col-xl-6 col-lg-6 col-md-8 col-sm-10 col-12"><input type="file" class="custom-file-input" name="image" id="customFile" title="'+tabText['format-supportaed']+'" onchange="changeFileLabel(this.value, \''+cls+'fileLabel\')" accept="image/*"><label class="custom-file-label" for="customFile" id="'+cls+'fileLabel">'+tabText['select-image']+'</label></div>';

                        var allProjectsEdit = "";
                        for(clsAllP in tab[cls]["all-skills"])
                        {
                            var sousTab = tab[cls]["all-skills"];

                            var input = '<div class="row" ><div class="col-xl-12"><div class="input-group mb-2"><input type="text" id="'+cls+'skillNameEdit'+clsAllP+'" class="form-control col-xl-12" name="'+cls+'name'+clsAllP+'" value="'+sousTab[clsAllP]["skill-name"]+'" placeholder="'+tabText['job-title']+'" /></div><div class="input-group"><textarea id="'+cls+'skillDetailsEdit'+clsAllP+'" class="form-control col-xl-12" rows="4" name="'+cls+'details'+clsAllP+'" placeholder="'+tabText['skil-text']+'" >'+sousTab[clsAllP]["skill-details"]+'</textarea></div></div></div>';
                            var btnSupp = '<div class="row"><div class="col-12 text-center pt-1"><span id="" class="all-buttons btn btn-outline-secondary btn-sm" onclick="deleteElem(\''+cls+clsAllP+'\')" title="'+delTitle+'"><i class="fas fa-trash-alt fa-sm"></i></span></div></div>';

                            allProjectsEdit += '<div class="container border border-1 p-2 mb-3" id="'+cls+clsAllP+'">'+input+btnSupp+'</div>';
                        }

                        var allInputEdit = '<div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12"><form method="post" id="'+cls+'form">'+titleEdit+menuTextEdit+imgEidt+allProjectsEdit+'</form><p id="'+cls+'msg" class="text-center mt-3"></p></div>';

                        var btnSaveEdit = '<i class="all-buttons fas fa-save btn btn-outline-success" onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\'); modifyData(\''+tab[cls]["type"]+'\', \''+cls+'form\', \''+cls+'field\', \''+cls+'fieldEdit\', \''+cls+'msg\', \''+cls+'\', \''+cls+'-imageContainer\')" title="'+tabText['save']+'"></i>';
                        var btnPlusEdit = '<i class="all-buttons fas fa-plus btn btn-outline-info mt-sm-2 ml-sm-0 ml-1" onclick="addInputField(\''+cls+'form\', \'exp_field\')" title="'+tabText['add']+'"></i>';
                        var btnCancelEdit = '<i class="all-buttons fas fa-times-circle btn btn-outline-warning mt-sm-2 ml-sm-0 ml-1"  onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\');" title="'+tabText['cancel']+'"></i>';

                        // var allBtnEdit = '<div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">'+btnSaveEdit+btnPlusEdit+btnCancelEdit+'<div id="'+cls+'-loading-container" style="display:none"><i class="fas fa-sync fa-spin p-4 mt-4"></i></div></div>';
                        var allBtnEdit = '<div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">'+btnSaveEdit+btnPlusEdit+btnCancelEdit+'</div>';

                        fieldEdit = '<div id="'+cls+'fieldEdit" class="row bg-light shadow-sm border border-1 mb-3 p-3 collapse"><div class="container"><div class="row">'+allInputEdit+allBtnEdit+'</div></div></div>';
                    }

                    /* ---------- prog_field ---------- */
                    else if(tab[cls]["type"] == "prog_field")
                    {
                        // Making the prog_field data
                        var btnSupp = '<i class="fas fa-times fa-sm btn-outline-secondary all-buttons float-right" title="'+tabText['del-this-field']+'" data-toggle="modal" data-target="#'+cls+'myModal"></i>';

                        var modalTitle = '<div class="modal-header"><h4 class="modal-title">'+tabText['warning']+'</h4><button type="button" class="close" data-dismiss="modal">&times;</button></div>';
                        var modalText = '<div class="modal-body">'+tabText['really-delete']+'</div>';
                        var modalBtn = '<div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal"  onclick="deleteElem(\''+cls+'field\'); deleteElem(\''+cls+'fieldEdit\'); newOrDeleteField(\'delete-a-generated-field\', '+cls+')">'+tabText['yes']+'</button><button type="button" class="btn btn-secondary" data-dismiss="modal">'+tabText['No']+'</button></div>';

                        var modalDiv = '<div class="modal fade" id="'+cls+'myModal"><div class="modal-dialog modal-dialog-centered"><div class="modal-content">'+modalTitle+modalText+modalBtn+'</div></div></div>';

                        var title = '<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"><h4 id="'+cls+'title" class="text-center">'+tab[cls]["title"]+btnSupp+'</h4></div>';
                        var menuText = '<p><strong>'+tabText['menu-text']+'</strong><span id="'+cls+'menuText">'+tab[cls]["menu-text"]+'</span></p>';

                        var allProjects = "";
                        for(clsAllP in tab[cls]["all-languages"])
                        {
                            var sousTab = tab[cls]["all-languages"];

                            allProjects += '<div class="row mb-3"><div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"><span><strong id="'+cls+'langName'+clsAllP+'">'+sousTab[clsAllP]["language-name"]+'</strong></span><span class="barLangue" ><meter max="100" id="'+cls+'langLevel'+clsAllP+'" value="'+sousTab[clsAllP]["language-level"]+'" class="ml-sm-3 w-50 progress_anglais" ></meter></span></div></div>';
                        }

                        var btnEdit = '<div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center"><i class="all-buttons fas fa-edit fa-sm btn btn-outline-info" title="'+tabText['edit-this-field']+'" onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\')"></i></div>';

                        var container = '<div class="container"><div class="row"><div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12" id="'+cls+'all-languages'+'">'+allProjects+'</div>'+btnEdit+'</div></div>';

                        field = '<div id="'+cls+'field" class="row bg-light shadow-sm border border-1 mb-3 p-3">'+title+menuText+container+modalDiv+'</div>';

                        // Making the prog_field-Edit data
                        var menuTextEdit = '<div class="input-group mb-2"><div class="input-group-prepend"><span id="'+cls+'menuTextEdit" class="input-group-text">'+tabText['menu-text']+'</span></div><input type="text" class="form-control" name="menuText" value="'+tab[cls]["menu-text"]+'" placeholder="'+tabText['languages']+'"/></div>';
                        var titleEdit = '<div class="form-groupe"><input type="text" id="'+cls+'titleEdit" class="mb-2 form-control text-uppercase" name="title" value="'+tab[cls]["title"]+'" placeholder="'+tabText['languages']+'" /></div>';

                        var allProjectsEdit = "";
                        for(clsAllP in tab[cls]["all-languages"])
                        {
                            var sousTab = tab[cls]["all-languages"];

                            var input = '<div class="row" ><div class="col-xl-12"><div class="input-group mb-2"><input type="text" id="'+cls+'langNameEdit'+clsAllP+'" class="form-control col-xl-12" name="'+cls+'name'+clsAllP+'" value="'+sousTab[clsAllP]["language-name"]+'" placeholder="'+tabText['english']+'" /></div><div class="input-group input-group-sm mb-2"><input type="number" id="'+cls+'langLevelEdit'+clsAllP+'" name="'+cls+'level'+clsAllP+'" min="1" max="100" value="'+sousTab[clsAllP]["language-level"]+'" class="form-control col-xl-2" placeholder="'+tabText['1-100']+'"></div></div></div>';
                            var btnSupp = '<div class="row"><div class="col-12 text-center pt-1"><span id="" class="all-buttons btn btn-outline-secondary btn-sm" onclick="deleteElem(\''+cls+clsAllP+'\')" title="'+delTitle+'"><i class="fas fa-trash-alt fa-sm"></i></span></div></div>';

                            allProjectsEdit += '<div class="container border border-1 p-2 mb-3" id="'+cls+clsAllP+'">'+input+btnSupp+'</div>';
                        }

                        var allInputEdit = '<div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12"><form method="post" id="'+cls+'form">'+titleEdit+menuTextEdit+allProjectsEdit+'</form><p id="'+cls+'msg" class="text-center mt-3"></p></div>';

                        var btnSaveEdit = '<i class="all-buttons fas fa-save btn btn-outline-success" onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\'); modifyData(\''+tab[cls]["type"]+'\', \''+cls+'form\', \''+cls+'field\', \''+cls+'fieldEdit\', \''+cls+'msg\', \''+cls+'\')" title="'+tabText['save']+'"></i>';
                        var btnPlusEdit = '<i class="all-buttons fas fa-plus btn btn-outline-info mt-sm-2 ml-sm-0 ml-1" onclick="addInputField(\''+cls+'form\', \'prog_field\')" title="'+tabText['add']+'"></i>';
                        var btnCancelEdit = '<i class="all-buttons fas fa-times-circle btn btn-outline-warning mt-sm-2 ml-sm-0 ml-1"  onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\');" title="'+tabText['cancel']+'"></i>';

                        var allBtnEdit = '<div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">'+btnSaveEdit+btnPlusEdit+btnCancelEdit+'</div>';

                        fieldEdit = '<div id="'+cls+'fieldEdit" class="row bg-light shadow-sm border border-1 mb-3 p-3 collapse"><div class="container"><div class="row">'+allInputEdit+allBtnEdit+'</div></div></div>';
                    }

                    /* ---------- img_field ---------- */
                    else if(tab[cls]["type"] == "img_field")
                    {
                        // Making the img_field data
                        var btnSupp = '<i class="fas fa-times fa-sm btn-outline-secondary all-buttons float-right" title="'+tabText['del-this-field']+'" data-toggle="modal" data-target="#'+cls+'myModal"></i>';

                        var modalTitle = '<div class="modal-header"><h4 class="modal-title">'+tabText['warning']+'</h4><button type="button" class="close" data-dismiss="modal">&times;</button></div>';
                        var modalText = '<div class="modal-body">'+tabText['really-delete']+'</div>';
                        var modalBtn = '<div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal"  onclick="deleteElem(\''+cls+'field\'); deleteElem(\''+cls+'fieldEdit\'); newOrDeleteField(\'delete-a-generated-field\', '+cls+')">'+tabText['yes']+'</button><button type="button" class="btn btn-secondary" data-dismiss="modal">'+tabText['No']+'</button></div>';

                        var modalDiv = '<div class="modal fade" id="'+cls+'myModal"><div class="modal-dialog modal-dialog-centered"><div class="modal-content">'+modalTitle+modalText+modalBtn+'</div></div></div>';

                        var title = '<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"><h4 id="'+cls+'title" class="text-center">'+tab[cls]["title"]+btnSupp+'</h4></div>';
                        var menuText = '<p><strong>'+tabText['menu-text']+'</strong><span id="'+cls+'menuText">'+tab[cls]["menu-text"]+'</span></p>';

                        var allProjects = "";
                        for(clsAllP in tab[cls]["all-hobbies"])
                        {
                            var sousTab = tab[cls]["all-hobbies"];

                            allProjects += '<div class="row mb-3"><div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"><div id="img_field_loading-'+cls+'-'+clsAllP+'" class="loading-container img_field_loading-'+cls+'" style="display: none; "><i class="fas fa-sync fa-spin"></i></div><img id="'+cls+'image'+clsAllP+'" src="'+sousTab[clsAllP]["hobby-image"]+'" alt="'+tabText['profile-image']+'" class="rounded-circle round_img_field_loading-'+cls+'" width="40px"/><span id="'+cls+'hobbyName'+clsAllP+'" class="ml-3">'+sousTab[clsAllP]["hobby-name"]+'</span></div></div>';
                        }

                        var projectTotal = '<div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12 mb-3" id="'+cls+'all-hobbies'+'">'+allProjects+'</div>';

                        var btnEdit = '<div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center"><i class="all-buttons fas fa-edit fa-sm btn btn-outline-info" title="'+tabText['edit-this-field']+'" onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\')"></i></div>';

                        var container = '<div class="container"><div class="row">'+projectTotal+btnEdit+'</div></div>';

                        field = '<div id="'+cls+'field" class="row bg-light shadow-sm border border-1 mb-3 p-3">'+title+menuText+container+modalDiv+'</div>';

                        // Making the img_field-Edit data
                        var menuTextEdit = '<div class="input-group mb-2"><div class="input-group-prepend"><span class="input-group-text">'+tabText['menu-text']+'</span></div><input id="'+cls+'menuTextEdit" type="text" class="form-control" name="menuText" value="'+tab[cls]["menu-text"]+'" placeholder="'+tabText['hobbies']+'"/></div>';
                        var titleEdit = '<div class="form-groupe"><input type="text" id="'+cls+'titleEdit" class="mb-2 form-control text-uppercase" name="title" value="'+tab[cls]["title"]+'" placeholder="'+tabText['hobbies']+'" /></div>';

                        var allProjectsEdit = "";
                        for(clsAllP in tab[cls]["all-hobbies"])
                        {
                            var sousTab = tab[cls]["all-hobbies"];

                            var img = '<div class="overflow-hidden custom-file custom-select-sm col-xl-6 col-lg-6 col-md-8 col-sm-10 col-12"><input type="file" class="custom-file-input" id="customFile" name="'+cls+'image'+clsAllP+'" title="'+tabText['format-supportaed']+'" accept="image/*"><label class="custom-file-label" for="customFile" id="'+cls+'fileLabel">'+tabText['select-image']+'</label></div>';
                            var inputField = '<div class="input-group mb-2"><input type="text" id="'+cls+'hobbyNameEdit'+clsAllP+'" class="form-control col-xl-12" name="'+cls+'name'+clsAllP+'" value="'+sousTab[clsAllP]["hobby-name"]+'" placeholder="'+tabText['bike']+'" /></div>';
                            var input = '<div class="row" ><div class="col-xl-12">'+img+inputField+'</div></div>';

                            var btnSupp = '<div class="row"><div class="col-12 text-center pt-1"><span id="" class="all-buttons btn btn-outline-secondary btn-sm" onclick="deleteElem(\''+cls+clsAllP+'\')" title="'+delTitle+'"><i class="fas fa-trash-alt fa-sm"></i></span></div></div>';

                            allProjectsEdit += '<div class="container border border-1 p-2 mb-3" id="'+cls+clsAllP+'">'+input+btnSupp+'</div>';
                        }

                        var allInputEdit = '<div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12"><form method="post" id="'+cls+'form">'+titleEdit+menuTextEdit+allProjectsEdit+'</form><p id="'+cls+'msg" class="text-center mt-3"></p></div>';

                        var btnSaveEdit = '<i class="all-buttons fas fa-save btn btn-outline-success" onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\'); modifyData(\''+tab[cls]["type"]+'\', \''+cls+'form\', \''+cls+'field\', \''+cls+'fieldEdit\', \''+cls+'msg\', \''+cls+'\')" title="'+tabText['save']+'"></i>';
                        var btnPlusEdit = '<i class="all-buttons fas fa-plus btn btn-outline-info mt-sm-2 ml-sm-0 ml-1" onclick="addInputField(\''+cls+'form\', \'img_field\')" title="'+tabText['add']+'"></i>';
                        var btnCancelEdit = '<i class="all-buttons fas fa-times-circle btn btn-outline-warning mt-sm-2 ml-sm-0 ml-1"  onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\');" title="'+tabText['cancel']+'"></i>';

                        var allBtnEdit = '<div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">'+btnSaveEdit+btnPlusEdit+btnCancelEdit+'</div>';

                        fieldEdit = '<div id="'+cls+'fieldEdit" class="row bg-light shadow-sm border border-1 mb-3 p-3 collapse"><div class="container"><div class="row">'+allInputEdit+allBtnEdit+'</div></div></div>';
                    }

                    /* ---------- hyper_field ---------- */
                    else if(tab[cls]["type"] == "hyper_field")
                    {
                        // Making the hyper_field data
                        var btnSupp = '<i class="fas fa-times fa-sm btn-outline-secondary all-buttons float-right" title="'+tabText['del-this-field']+'" data-toggle="modal" data-target="#'+cls+'myModal"></i>';

                        var modalTitle = '<div class="modal-header"><h4 class="modal-title">'+tabText['warning']+'</h4><button type="button" class="close" data-dismiss="modal">&times;</button></div>';
                        var modalText = '<div class="modal-body">'+tabText['really-delete']+'</div>';
                        var modalBtn = '<div class="modal-footer"><button type="button" class="btn btn-secondary" data-dismiss="modal"  onclick="deleteElem(\''+cls+'field\'); deleteElem(\''+cls+'fieldEdit\'); newOrDeleteField(\'delete-a-generated-field\', '+cls+')">'+tabText['yes']+'</button><button type="button" class="btn btn-secondary" data-dismiss="modal">'+tabText['No']+'</button></div>';

                        var modalDiv = '<div class="modal fade" id="'+cls+'myModal"><div class="modal-dialog modal-dialog-centered"><div class="modal-content">'+modalTitle+modalText+modalBtn+'</div></div></div>';

                        var title = '<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"><h4 id="'+cls+'title" class="text-center">'+tab[cls]["title"]+btnSupp+'</h4></div>';
                        var menuText = '<p><strong>'+tabText['menu-text']+'</strong><span id="'+cls+'menuText">'+tab[cls]["menu-text"]+'</span></p>';

                        var allProjects = "";
                        for(clsAllP in tab[cls]["all-projects"])
                        {
                            var sousTab = tab[cls]["all-projects"];

                            var pImg = '<img id="'+cls+'image'+clsAllP+'" src="'+sousTab[clsAllP]["project-image"]+'" alt="'+tabText['profile-image']+'" class="rounded-circle" width="40px"/>';
                            var pName = '<span id="'+cls+'projectName'+clsAllP+'" class="ml-3">'+sousTab[clsAllP]["project-name"]+'</span>';
                            var PLien = '<span class="ml-3"><a id="'+cls+'hyperlink'+clsAllP+'" href="'+sousTab[clsAllP]["project-hyperlink"]+'" >'+sousTab[clsAllP]["project-hyperlink-name"]+'</a></span>';

                            allProjects += '<div class="row mb-3"><div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">'+pImg+pName+PLien+'</div></div>';
                        }

                        var projectTotal = '<div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12 mb-3" id="'+cls+'all-projects'+'">'+allProjects+'</div>';

                        var btnEdit = '<div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center"><i class="all-buttons fas fa-edit fa-sm btn btn-outline-info" title="'+tabText['edit-this-field']+'" onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\')"></i></div>';

                        var container = '<div class="container"><div class="row">'+projectTotal+btnEdit+'</div></div>';

                        field = '<div id="'+cls+'field" class="row bg-light shadow-sm border border-1 mb-3 p-3">'+title+menuText+container+modalDiv+'</div>';

                        // Making the hyper_field-Edit data
                        var menuTextEdit = '<div class="input-group mb-2"><div class="input-group-prepend"><span id="'+cls+'menuTextEdit" class="input-group-text">'+tabText['menu-text']+'</span></div><input type="text" class="form-control" name="menuText" value="" placeholder="'+tabText['my-projects']+'"/></div>';
                        var titleEdit = '<div class="form-groupe"><input type="text" id="'+cls+'titleEdit" class="mb-2 form-control text-uppercase" name="title" value="'+tab[cls]["title"]+'" placeholder="'+tabText['my-projects']+'" /></div>';

                        var allProjectsEdit = "";
                        for(clsAllP in tab[cls]["all-projects"])
                        {
                            var sousTab = tab[cls]["all-projects"];

                            var btnSupp = '<div class="row"><div class="col-12 text-center pt-1"><span id="" class="all-buttons btn btn-outline-secondary btn-sm" onclick="deleteElem(\''+cls+clsAllP+'\')" title="'+delTitle+'"><i class="fas fa-trash-alt fa-sm"></i></span></div></div>';

                            var inputFile = '<div class="overflow-hidden custom-file custom-select-sm col-xl-6 col-lg-6 col-md-8 col-sm-10 col-12"><input type="file" class="custom-file-input" id="customFile" name="'+cls+'image'+clsAllP+'" title="'+tabText['format-supportaed']+'"><label class="custom-file-label" for="customFile" id="'+cls+'fileLabel">'+tabText['select-image']+'</label></div>';
                            var inputName = '<div class="input-group mb-2"><input type="text" id="'+cls+'projNameEdit'+clsAllP+'" class="form-control col-xl-12" name="'+cls+'name'+clsAllP+'" value="'+sousTab[clsAllP]["project-name"]+'" placeholder="'+tabText['my-blog']+'" /></div>';
                            var inputLink = '<div class="input-group mb-2"><input type="text" id="'+cls+'projLinkEdit'+clsAllP+'" class="form-control col-xl-12" name="'+cls+'link'+clsAllP+'" value="'+sousTab[clsAllP]["project-hyperlink"]+'" placeholder="'+tabText['site-web']+'" /></div>';
                            var inputLinkName = '<div class="input-group mb-2"><input type="text" id="'+cls+'projLinknameEdit'+clsAllP+'" class="form-control col-xl-12" name="'+cls+'linkName'+clsAllP+'" value="'+sousTab[clsAllP]["project-hyperlink-name"]+'" placeholder="'+tabText['click-here']+'" /></div>';

                            var inputAll = '<div class="row" ><div class="col-xl-12">'+inputFile+inputName+inputLink+inputLinkName+'</div></div>';

                            allProjectsEdit += '<div class="container border border-1 p-2 mb-3" id="'+cls+clsAllP+'">'+inputAll+btnSupp+'</div>';
                        }

                        var allInputEdit = '<div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12"><form method="post" id="'+cls+'form">'+titleEdit+menuTextEdit+allProjectsEdit+'</form><p id="'+cls+'msg" class="text-center mt-3"></p></div>';

                        var btnSaveEdit = '<i class="all-buttons fas fa-save btn btn-outline-success" onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\'); modifyData(\''+tab[cls]["type"]+'\', \''+cls+'form\', \''+cls+'field\', \''+cls+'fieldEdit\', \''+cls+'msg\', \''+cls+'\')" title="'+tabText['save']+'"></i>';
                        var btnPlusEdit = '<i class="all-buttons fas fa-plus btn btn-outline-info mt-sm-2 ml-sm-0 ml-1" onclick="addInputField(\''+cls+'form\', \'hyper_field\')" title="'+tabText['add']+'"></i>';
                        var btnCancelEdit = '<i class="all-buttons fas fa-times-circle btn btn-outline-warning mt-sm-2 ml-sm-0 ml-1"  onclick="slideAnim(\''+cls+'field\', \''+cls+'fieldEdit\');" title="'+tabText['cancel']+'"></i>';

                        var allBtnEdit = '<div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">'+btnSaveEdit+btnPlusEdit+btnCancelEdit+'</div>';

                        fieldEdit = '<div id="'+cls+'fieldEdit" class="row bg-light shadow-sm border border-1 mb-3 p-3 collapse"><div class="container"><div class="row">'+allInputEdit+allBtnEdit+'</div></div></div>';
                    }

                    generatedField += field+fieldEdit;
                }

                document.getElementById("field-position").innerHTML = fieldOption;
                document.getElementById("generated-field").innerHTML = generatedField;
            }
            else if(id == "form-new-field")
            {
                if(this.responseText == "done")
                {
                    var myVar;
                    clearTimeout(myVar);

                    byId("msg-field").innerHTML = tabText['field-is-added'];

                    byId("fieldDefault").selected = "true";
                    byId("field-position").innerHTML = "";

                    newOrDeleteField("display-generated-fields", "all");

                    displayData(Recup("lang-default"));

                    myVar = setTimeout(function(){
                        byId("msg-field").innerHTML = '';
                    }, 5000);
                }
                else
                {
                    byId("msg-field").innerHTML = this.responseText;
                }
            }
            else if(purpose == "delete-a-generated-field")
            {
                displayData(Recup("lang-default"));
            }

            convertToHTML ('.col-xl-12.col-lg-12.col-md-12.col-sm-12.col-12.ml-sm-4 span');
        }
    }
}


if(Recup('lang-default') == undefined) {
    if(isoLangs[navigator.language] == undefined) {
        Enrg("lang-default", 'Français');
    }
    else {
        Enrg("lang-default", isoLangs[navigator.language]['nativeName']);
    }
}

// Function for getting all the data from the database and display to the visitor.
function displayData(language)
{
    var data = new FormData();
    data.append("lang-default", language);

    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            var dataCV = JSON.parse(this.responseText);

            // ------------------- Displaying the title data. -------------------
            if(dataCV.profil_img["src"] != "")
            {
                byId("profil_img-div").innerHTML = '<img src="'+dataCV.profil_img["src"]+'" alt="'+tabText['image']+'" id="profil-img" class="rounded-circle img-thumbnail"/>';
            }
            else
            {
                byId("profil_img-div").innerHTML = '<img src="img/img-default.jpg" alt="'+tabText['image']+'" id="profil-img" class="rounded-circle img-thumbnail"/>';
            }

            // ------------------- Displaying the TITLE data. -------------------
            byId("title-title").innerHTML = '<h4 id="title-title" class="text-center">'+dataCV.cv_title["title-title-edit"]+'</h4>';
            byId("title").innerHTML = '<p>'+dataCV.cv_title["name-edit"]+'</p><p>'+dataCV.cv_title["title-edit"]+'</p>';

            byId("title-title-edit").value = dataCV.cv_title["title-title-edit"];
            byId("name-edit").value = dataCV.cv_title["name-edit"];
            byId("title-edit").value = dataCV.cv_title["title-edit"];

            // ------------------- Displaying the SUMMARY data. -------------------
            byId("summary-title").innerHTML = dataCV.summary["title-summary-edit"];
            byId("summary").innerHTML = '<p><strong>'+tabText['menu-text']+'</strong>'+dataCV.summary["menu-summary"]+'</p><p>'+dataCV.summary["summary-edit"]+'</p>';

            byId("menu-summary").value = dataCV.summary["menu-summary"];
            byId("title-summary-edit").value = dataCV.summary["title-summary-edit"];
            byId("summary-edit").value = dataCV.summary["summary-edit"];

            // ------------------- Displaying the profil_field data. -------------------
            byId("title-profil_field").innerHTML = dataCV.profil_field["title-profil_field"];
            var menuText = '<div class="row"><div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"><p><span><strong>'+tabText['menu-text']+'</strong></span><span>'+dataCV.profil_field["menu-profil_field"]+'</span></div></div>';

            var menuTextEdit = '<div class="input-group mb-2"><div class="input-group-prepend"><span class="input-group-text">'+tabText['menu-text']+'</span></div><input type="text" id="menu-profil_field-edit" name="menu-profil_field" class="form-control" value="'+dataCV.profil_field["menu-profil_field"]+'" placeholder="'+tabText['profile']+'"/></div>';
            var titleEdit = '<div class="form-groupe"><input type="text" id="title-profil_field-edit" name="title-profil_field" class="mb-2 form-control text-uppercase" value="'+dataCV.profil_field["title-profil_field"]+'" placeholder="'+tabText['profile']+'" /></div>';

            // using for() loop to display profile data of different number.
            var elem = ""; // Variable to hold data to display as text.
            var elemEdit = ""; // Variable to hold data to display as an input filed for editing.
            var ct = 0;
            var idElem1 = null;
            var idElem2 = null;

            // Deleting some elements of our dataCV.profil_field object in order to make easy our for() loop.
            delete dataCV.profil_field.field;
            delete dataCV.profil_field["menu-profil_field"];
            delete dataCV.profil_field["title-profil_field"];

            for(cls in dataCV.profil_field)
            {
                if(ct%2 == 0)
                {
                    idElem1 = Number(cls);

                    elem += '<div class="row"><div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"><span><strong>'+dataCV.profil_field[cls]+' </strong></span>';
                    elemEdit += '<div class="input-group mb-2" id="'+idElem1+'"><input type="text" id="title-date-name" name="'+idElem1+'" class="form-control col-12" value="'+dataCV.profil_field[cls]+'" placeholder="'+tabText['d-o-b']+'" />';
                }
                else if(ct%2 == 1)
                {
                    idElem2 = Number(cls);

                    elem += '<span>'+dataCV.profil_field[cls]+'</span></div></div>';
                    elemEdit += '<input type="text" id="title-date-value" name="'+idElem2+'" class="form-control col-12 ml-3" value="'+dataCV.profil_field[cls]+'" placeholder="'+tabText['d-o-b-digit']+'" /><div class="input-group-append"><span id="" onclick="deleteElem(\''+idElem1+'\')" class="delete-filed input-group-text btn btn-secondary"><i class="fas fa-trash-alt fa-sm"></i></span></div></div>';
                }

                ct += 1;
            }
            byId("profil_field").innerHTML = menuText+elem;
            byId("form-profil-field").innerHTML = titleEdit+menuTextEdit+elemEdit;

            byId("title-social_net").innerHTML = dataCV.social_net["social-networks"];
            var titleEdit = '<div class="form-groupe"><input type="text" id="social-networks-edit" name="social-networks" class="mb-2 form-control" value="'+dataCV.social_net["social-networks"]+'" placeholder="'+tabText['social-network']+'" /></div>';

            // using for() loop to display the social-networks data of different number.
            var elem = ""; // Variable to hold data to display as text.
            var elemEdit = ""; // Variable to hold data to display as an input filed for editing.
            var ct = 0; // Variable used to count the repetition of the loop.
            var idElem1 = null;
            var idElem2 = null;
            var snName = null;
            var snUrl = null;
            var optionElem = null;
            var nomRS = null; // I used this variable to the value of Social-network for title="" attribute.

            for(cls in dataCV.social_net)
            {
                // Condition to delete the first elements of our dataCV.social_net object.
                if(ct > 0)
                {
                    if(ct%2 == 1)
                    {
                        // Looping through SN object for creating <opiton> element.
                        for(x in SN)
                        {
                            if(x == dataCV.social_net[cls])
                            {
                                optionElem += '<option value="'+x+'" selected>'+x+'</option>';
                                nomRS = x;
                            }
                            else
                            {
                                optionElem += '<option value="'+x+'">'+x+'</option>';
                            }
                        }

                        idElem1 = cls;
                        snName = dataCV.social_net[cls];
                    }
                    else if(ct%2 == 0)
                    {
                        idElem2 = cls;
                        snUrl = dataCV.social_net[cls];

                        elem += '<a href="'+snUrl+'" target="_new" ><i class="'+SN[snName]+'" title="'+nomRS+'"></i></a>';
                        elemEdit += '<div class="container border border-1 p-2 mb-3" id="'+idElem1+'"><div class="row" ><div class="col-xl-12"><select value="" name="'+idElem1+'" class="custom-select custom-select-sm col-xl-4 col-lg-3 col-md-4 col-sm-6 col-12 mb-2">'+optionElem+'</select><div class="input-group mb-2"><input type="text" name="'+idElem2+'" class="form-control col-xl-12" value="'+snUrl+'" placeholder="'+tabText['social-net-url']+'" /></div></div></div><div class="row"><div class="col-12 text-center pt-1"><span id="" class="all-buttons delete-filed btn btn-outline-secondary btn-sm" onclick="deleteElem(\''+idElem1+'\')" title="'+tabText['delete']+'"><i class="fas fa-trash-alt fa-sm"></i></span></div></div></div>';
                        optionElem = null;
                    }
                }
                ct += 1;
            }
            byId("social-network").innerHTML = elem;
            byId("form-social-net").innerHTML = titleEdit+elemEdit;

            // ------------------- Displaying update date. -------------------
            byId("update-date").innerHTML = '<span><strong>'+dataCV.update_date["date-label"]+' </strong></span><span>'+dataCV.update_date["date"]+'</span>';

            byId("date-label").value = dataCV.update_date["date-label"];
            byId("date").value = dataCV.update_date["date"];


            // Updating the field position in the dropdown menu once a field is deleted.
            // newOrDeleteField('display-generated-fields', 'all');

            convertToHTML('.col-xl-12.col-lg-12.col-md-12.col-sm-12.col-12.ml-sm-4 span');
        }
    }

    // Dispalaying the admin language selected <option>
    byId('admin-languages').value = Recup("adminLang");

}

/* ------------------------------------------ */
/* ------ Uploading the profile image ------- */
/* ------------------------------------------ */

$(document).ready(function() {
    $('profil-img-edit').change(function(e) {

        imgFile = e.target.files['0'];

        if(!imgFile) {
            return;
        }

        // Getting the current image's source in order to delete it from the server.
        var currentImg = byId("profil-img").src;

        // While uploading
        byId("profil_img-div").innerHTML='<i class="fas fa-sync fa-spin p-4 mt-4"></i>';
        byId("profil-img-edit").disabled=true;

        const reader = new FileReader();

        imgSrcInput = reader.readAsDataURL(imgFile);

        reader.onload = function(e) {

            options = {
                strict: true,
                checkOrientation: true,
                maxWidth: undefined,
                maxHeight: undefined,
                minWidth: 0,
                minHeight: 0,
                width: 600,
                height: undefined,
                quality: 0.9,
                mimeType: '',
                convertSize: 5000000,

                success: function (result) {

                    const readerCompressed = new FileReader();

                    imgSrcInput = readerCompressed.readAsDataURL(result);

                    readerCompressed.onload = function(e) {
                        // Generating the download url of the output image.
                        result.name = 'compressed-'+result.name;
                    }

                    byId("msg-profil_img").innerHTML = "";

                    var file = byId("profil-img-edit").files;


                    // Generating the download url of the output image.
                    var compressedName = file[0]['name'];
                    compressedName = compressedName.toLowerCase();
                    compressedName = compressedName.replaceAll(' ', '-');

                    // Using Javascript interface FormData() and for loop to collect informations about images.
                    var data = new FormData();

                    data.append("field", "profil_img");
                    data.append("language", Recup("lang-default"));
                    data.append("src", currentImg);

                    data.append('profil_img', result);
                    data.append('image-extension', file[0]['name'].split('.').pop());
                    data.append('compressed-name', compressedName);

                    var tailleF = Math.ceil(file["size"]/1000000);

                    if(tailleF > 8)
                    {
                        byId("msg-profil_img").innerHTML="'+tabText['file-size-exceeds']+'";
                    }
                    else
                    {
                        // XMLHttpRequest() request
                        if(window.XMLHttpRequest)
                        {
                            var xHttp = new XMLHttpRequest();
                        }
                        else
                        {
                            var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
                        }

                        xHttp.open("POST", "php.php", true);
                        xHttp.send(data);

                        xHttp.onreadystatechange = function()
                        {
                            if(this.status == 200 && this.readyState == 4)
                            {
                                if(this.responseText == "done")
                                {
                                    byId("profil-img-edit").disabled=false;
                                    byId("form-profil-img").reset();
                                    displayData(Recup("lang-default"));
                                }
                                else
                                {
                                    byId("msg-profil_img").innerHTML=this.responseText;
                                    byId("profil-img-edit").disabled=false;
                                    displayData(Recup("lang-default"));
                                }
                            }
                        }
                    }

                },
            }

            new Compressor(imgFile, options);
        };
    });
});


/* ------------------------------------------ */
/* -- Uploading image for generated fields -- */
/* ------------------------------------------ */

function xmlModifyData(data, field, fieldText, fieldInput, msgBox) {
    // XMLHttpRequest() resquest.
    if(window.XMLHttpRequest)
    {
        var xHttp = new XMLHttpRequest();
    }
    else
    {
        var xHttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xHttp.open("POST", "php.php", true);
    xHttp.send(data);

    xHttp.onreadystatechange = function()
    {
        if(this.status == 200 && this.readyState == 4)
        {
            // Script for the generated fields. The data sent from server will be in JSON form.
            var tabFields = ["exp_field", "prog_field", "img_field", "hyper_field",];
            if(tabFields.includes(field))
            {
                var donnees = JSON.parse(this.responseText);
            }

            if(this.responseText == "done")
            {
                displayData(Recup("lang-default"));

                slideAnim(fieldText, fieldInput);
            }
            else if(donnees != undefined && donnees.includes("Taj")) // sould check this condition because the variable "donnees" can cause an error.
            {
                if(field == "exp_field")
                {
                    var tab = donnees[1];

                    var btnSupp = '<i class="fas fa-times fa-sm btn-outline-secondary all-buttons float-right" title="'+tabText['del-this-field']+'" data-toggle="modal" data-target="#'+cls+'myModal"></i>';

                    byId(tab["id"]+"title").innerHTML = tab["title"]+btnSupp;
                    byId(tab["id"]+"menuText").innerHTML = tab["menu-text"];

                    byId(tab["id"]+"titleEdit").innerHTML = tab["title"];
                    byId(tab["id"]+"menuTextEdit").innerHTML = tab["menu-text"];

                    var allProjects = "";
                    for(cls in tab["all-skills"])
                    {
                        var sousTab = tab["all-skills"][cls];

                        var img = '<img id="'+tab["id"]+'image'+cls+'" src="'+tab["img"]+'" alt="" width="15px"/>';
                        var span = '<span  class="ml-sm-2"><strong id="'+tab["id"]+'skillName'+cls+'">'+sousTab["skill-name"]+'</strong></span>';
                        var divImgSpan = '<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 '+field+'-imageContainer">'+img+span+'</div>';

                        var divDetail = '<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ml-sm-4"><span id="'+tab["id"]+'skillDetails'+cls+'" class="">'+sousTab["skill-details"]+'</span></div>';

                        allProjects += '<div class="row mb-3">'+divImgSpan+divDetail+'</div>';
                    }

                    byId(tab["id"]+"all-skills").innerHTML = allProjects;
                }
                else if(field == "prog_field")
                {
                    var tab = donnees[1];

                    var btnSupp = '<i class="fas fa-times fa-sm btn-outline-secondary all-buttons float-right" title="'+tabText['del-this-field']+'" data-toggle="modal" data-target="#'+cls+'myModal"></i>';

                    byId(tab["id"]+"title").innerHTML = tab["title"]+btnSupp;
                    byId(tab["id"]+"menuText").innerHTML = tab["menu-text"];

                    byId(tab["id"]+"titleEdit").innerHTML = tab["title"];
                    byId(tab["id"]+"menuTextEdit").innerHTML = tab["menu-text"];

                    var allLanguages = "";
                    for(cls in tab["all-languages"])
                    {
                        var sousTab = tab["all-languages"][cls];

                        var spanName = '<span><strong id="'+tab["id"]+'langName'+cls+'">'+sousTab["language-name"]+'</strong></span>';
                        var spanLevel = '<span class="barLangue" ><meter max="100" id="'+tab["id"]+'langLevel'+cls+'" value="'+sousTab["language-level"]+'" class="ml-sm-3 w-50 progress_anglais" ></meter></span>';
                        allLanguages += '<div class="row mb-3"><div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">'+spanName+spanLevel+'</div></div>';
                    }

                    byId(tab["id"]+"all-languages").innerHTML = allLanguages;
                }
                else if(field == "img_field")
                {
                    var tab = donnees[1];

                    var btnSupp = '<i class="fas fa-times fa-sm btn-outline-secondary all-buttons float-right" title="'+tabText['del-this-field']+'" data-toggle="modal" data-target="#'+cls+'myModal"></i>';

                    byId(tab["id"]+"title").innerHTML = tab["title"]+btnSupp;
                    byId(tab["id"]+"menuText").innerHTML = tab["menu-text"];

                    byId(tab["id"]+"titleEdit").innerHTML = tab["title"];
                    byId(tab["id"]+"menuTextEdit").innerHTML = tab["menu-text"];

                    var allHobbies = "";
                    for(cls in tab["all-hobbies"])
                    {
                        var sousTab = tab["all-hobbies"][cls];

                        var img = '<img id="'+tab["id"]+'image'+cls+'" src="'+sousTab["hobby-image"]+'" alt="'+tabText['profile-image']+'" class="rounded-circle" width="40px"/>';
                        var span = '<span id="'+tab["id"]+'hobbyName'+cls+'" class="ml-3">'+sousTab["hobby-name"]+'</span>';
                        allHobbies += '<div class="row mb-3"><div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">'+img+span+'</div></div>';
                    }

                    byId(tab["id"]+"all-hobbies").innerHTML = allHobbies;
                }
                else if(field == "hyper_field")
                {
                    var tab = donnees[1];

                    var btnSupp = '<i class="fas fa-times fa-sm btn-outline-secondary all-buttons float-right" title="'+tabText['del-this-field']+'" data-toggle="modal" data-target="#'+cls+'myModal"></i>';

                    byId(tab["id"]+"title").innerHTML = tab["title"]+btnSupp;
                    byId(tab["id"]+"menuText").innerHTML = tab["menu-text"];

                    byId(tab["id"]+"titleEdit").innerHTML = tab["title"];
                    byId(tab["id"]+"menuTextEdit").innerHTML = tab["menu-text"];

                    var allProject = "";
                    for(cls in tab["all-projects"])
                    {
                        var sousTab = tab["all-projects"][cls];

                        var projImg = '<img id="'+tab["id"]+'image'+cls+'" src="'+sousTab["project-image"]+'" alt="'+tabText['profile-image']+'" class="rounded-circle" width="40px"/>';
                        var projName = '<span id="'+tab["id"]+'projectName'+cls+'" class="ml-3">'+sousTab["project-name"]+'</span>';
                        var projHyperlink = '<span class="ml-3"><a id="'+tab["id"]+'hyperlink'+cls+'" href="'+sousTab["project-hyperlink"]+'" >'+sousTab["project-hyperlink-name"]+'</a></span>';

                        allProject += '<div class="row mb-3"><div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">'+projImg+projName+projHyperlink+'</div></div>';
                    }

                    byId(tab["id"]+"all-projects").innerHTML = allProject;
                }

                displayData(Recup("lang-default"));
            }
            else
            {
                byId(msgBox).innerHTML = this.responseText;
            }
        }
    }
}

/* Function for modifying the data in the database.
* - field : is the name of the field.
* - form : is the id the form.
* - fieldText : is the id of the displaying div.
* - fieldInput : is the id of the displaying input.
* - msgBox : is the id of message element i.e <p></p>.
* - idField :
* - imgContainer : is the class name of the loading icon
*/

function modifyData(field, form, fieldText, fieldInput, msgBox, idField, imgContainer)
{
    var imgFile = undefined;

    if($('#'+form+' input:file').length > 0) {
        imgFile = $('#'+form+' input:file')[0].files[0];
    }

    if(imgFile != undefined) {
        // Getting the current image's source in order to delete it from the server.
        /* var currentImg = byId("profil-img").src; */

        // While uploading
        if(field == 'exp_field') {
            var imgContainer = document.getElementsByClassName(imgContainer);

            for(x in imgContainer) {
                // byId(imgContainer).innerHTML = '<div id="exp_field-loading-container" class="loading-container"><i class="fas fa-sync fa-spin"></i></div>';
                imgContainer[x].innerHTML = '<div id="exp_field-loading-container" class="loading-container"><i class="fas fa-sync fa-spin"></i></div>';
            }
        }

        /* // While uploading
        if(field == 'img_field') {

            var image_loading = document.getElementsByClassName('img_field_loading-'+field);
            var round_image_loading = document.getElementsByClassName('round_img_field_loading-'+field);

            var ct = 0;
            for(x in image_loading) {

                // byId(imgContainer).innerHTML = '<div id="exp_field-loading-container" class="loading-container"><i class="fas fa-sync fa-spin"></i></div>';
                // image_loading[x].innerHTML = '<div id="exp_field-loading-container" class="loading-container" style="display: contents;"><i class="fas fa-sync fa-spin"></i></div>';
                image_loading[x].style.display = 'block';
                round_image_loading.style.display = 'none';

                ct += 1;
            }
        } */

        const reader = new FileReader();

        imgSrcInput = reader.readAsDataURL(imgFile);

        reader.onload = function(e) {

            options = {
                strict: true,
                checkOrientation: true,
                maxWidth: undefined,
                maxHeight: undefined,
                minWidth: 0,
                minHeight: 0,
                width: 500,
                height: undefined,
                quality: 0.8,
                mimeType: '',
                convertSize: 5000000,

                success: function (result) {

                    const readerCompressed = new FileReader();

                    imgSrcInput = readerCompressed.readAsDataURL(result);

                    /* readerCompressed.onload = function(e) {
                        // Creating the image title
                        result.name = result.name;
                    } */

                    // Creating the image title
                    var compressedName = imgFile['name'];
                    compressedName = compressedName.toLowerCase();
                    compressedName = compressedName.replaceAll(' ', '-');


                    var data = new FormData(byId(form));

                    data.append("field", field);
                    data.append("language", Recup("lang-default"));
                    data.append("id", idField);


                    /* data.append("src", currentImg); */

                    data.append('image', result);
                    data.append('image_extension', imgFile['name'].split('.').pop());
                    data.append('compressed_name', compressedName);

                    xmlModifyData(data, field, fieldText, fieldInput, msgBox);
                },
            }

            new Compressor(imgFile, options);
        };
    }

    else {
        var data = new FormData(byId(form));

        data.append("field", field);
        data.append("language", Recup("lang-default"));
        data.append("id", idField);

        xmlModifyData(data, field, fieldText, fieldInput, msgBox);
    }

}

// Random code generation function, used for id and name attributes.
function generRand()
{
    var d = new Date();
    d = d.getFullYear()+""+(d.getMonth()+1)+""+d.getDate()+""+d.getSeconds()+""+d.getMilliseconds()

    var generer = d+""+Math.floor((Math.random() * 999999) + 1);
    return generer;
}

// Function for adding more input fields.
if(tabText != undefined) {
    var delTitle = tabText['delete'];
}
function addInputField(idTarget, field)
{
    var hasard = generRand();
    hasard = Number(hasard); // I convert the generated number from string to number type.

    // An object containing all the new field that we will add to our needs.
    var elem =
    {
        profil_field : '<div class="input-group mb-2" id="'+hasard+'"><input type="text" name="'+Number(generRand())+'" class="form-control col-12" value="" placeholder="'+tabText['d-o-b-:']+'" /><input type="text" name="'+Number(generRand())+'" class="form-control col-12 ml-3" value="" placeholder="'+tabText['d-o-b-digit']+'" /><div class="input-group-append"><span onclick="deleteElem(\''+hasard+'\')" class="all-buttons delete-filed input-group-text btn btn-secondary" title="'+delTitle+'"><i class="fas fa-trash-alt fa-sm"></i></span></div></div>',
        exp_field : '<div class="container border border-1 p-2 mb-3" id="'+hasard+'"><div class="row" ><div class="col-xl-12"><div class="input-group mb-2"><input type="text" name="'+Number(generRand())+'" class="form-control col-xl-12" value="" placeholder="'+tabText['software-editor']+'" /></div><div class="input-group"><textarea name="'+Number(generRand())+'" class="form-control col-xl-12" rows="4" placeholder="'+tabText['some-text-exp']+'" ></textarea></div></div></div><div class="row"><div class="col-12 text-center pt-1"><span id="" class="all-buttons delete-filed btn btn-outline-secondary btn-sm" onclick="deleteElem(\''+hasard+'\')" title="'+delTitle+'"><i class="fas fa-trash-alt fa-sm"></i></span></div></div></div>',
        prog_field : '<div class="container border border-1 p-2 mb-3" id="'+hasard+'"><div class="row" ><div class="col-xl-12"><div class="input-group mb-2"><input type="text" name="'+Number(generRand())+'" class="form-control col-xl-12" value="" placeholder="'+tabText['english']+'" /></div><div class="input-group input-group-sm mb-2"><input type="number" name="'+Number(generRand())+'" min="1" max="100" class="form-control col-xl-2" placeholder="'+tabText['1-100']+'"></div></div></div><div class="row"><div class="col-12 text-center pt-1"><span id="" class="all-buttons delete-filed btn btn-outline-secondary btn-sm" onclick="deleteElem(\''+hasard+'\')" title="'+delTitle+'"><i class="fas fa-trash-alt fa-sm"></i></span></div></div></div>',
        img_field : '<div class="container border border-1 p-2 mb-3" id="'+hasard+'"><div class="row" ><div class="col-xl-12"><div class="overflow-hidden custom-file custom-select-sm col-xl-6 col-lg-6 col-md-8 col-sm-10 col-12"><input type="file"name="'+Number(generRand())+'" class="custom-file-input" id="customFile" title="'+tabText['format-supportaed']+'" accept="image/*"><label class="custom-file-label" for="customFile" id="'+hasard+'fileLabel">'+tabText['select-image']+'</label></div><div class="input-group mb-2"><input type="text" name="'+Number(generRand())+'" class="form-control col-xl-12" value="" placeholder="'+tabText['bike']+'" /></div></div></div><div class="row"><div class="col-12 text-center pt-1"><span id="" class="all-buttons delete-filed btn btn-outline-secondary btn-sm" onclick="deleteElem(\''+hasard+'\')" title="'+delTitle+'"><i class="fas fa-trash-alt fa-sm"></i></span></div></div></div>',
        hyper_field : '<div class="container border border-1 p-2 mb-3" id="'+hasard+'"><div class="row" ><div class="col-xl-12"><div class="overflow-hidden custom-file custom-select-sm col-xl-6 col-lg-6 col-md-8 col-sm-10 col-12"><input type="file" name="'+Number(generRand())+'" class="custom-file-input" id="customFile" title="'+tabText['format-supportaed']+'" accept="image/*"><label class="custom-file-label" for="customFile" id="'+hasard+'fileLabel">'+tabText['select-image']+'</label></div><div class="input-group mb-2"><input type="text" name="'+Number(generRand())+'" class="form-control col-xl-12" value="" placeholder="'+tabText['my-blog']+'" /></div><div class="input-group mb-2"><input type="text" name="'+Number(generRand())+'" class="form-control col-xl-12" value="" placeholder="'+tabText['site-web']+'" /></div><div class="input-group mb-2"><input type="text" name="'+Number(generRand())+'" class="form-control col-xl-12" value="" placeholder="'+tabText['click-here']+'" /></div></div></div><div class="row"><div class="col-12 text-center pt-1"><span id="" class="all-buttons delete-filed btn btn-outline-secondary btn-sm" onclick="deleteElem(\''+hasard+'\')" title="'+delTitle+'"><i class="fas fa-trash-alt fa-sm"></i></span></div></div></div>',
        social_net : '<div class="container border border-1 p-2 mb-3" id="'+hasard+'"><div class="row" ><div class="col-xl-12"><select class="custom-select custom-select-sm col-xl-4 col-lg-3 col-md-4 col-sm-6 col-12 mb-2" name="'+Number(generRand())+'"><option value="Facebook">Facebook</option><option value="Blog">Blog</option><option value="Twitter">Twitter</option><option value="Linkedin">Linkedin</option><option value="Viadeo">Viadeo</option><option value="Instagram">Instagram</option><option value="Snapshat">Snapshat</option><option value="Google">Google+</option><option value="Pinterest">Pinterest</option><option value="Tumblr">Tumblr</option><option value="Youtube">Youtube</option><option value="Share">Share</option><option value="Internet">Internet</option></select><div class="input-group mb-2"><input type="text" name="'+Number(generRand())+'" class="form-control col-xl-12" value="" placeholder="'+tabText['social-net-url']+'" /></div></div></div><div class="row"><div class="col-12 text-center pt-1"><span id="" class="all-buttons delete-filed btn btn-outline-secondary btn-sm" onclick="deleteElem(\''+hasard+'\')" title="'+delTitle+'"><i class="fas fa-trash-alt fa-sm"></i></span></div></div></div>',
    }

    byId(idTarget).insertAdjacentHTML("beforeend", elem[field]); // Adding new HTML elements at the last.
}

// Function for deleting an input field.
function deleteElem(idTarget)
{
    byId(idTarget).parentNode.removeChild(byId(idTarget));
}

// Function for deleting an input field.
function changeFileLabel(fileValue, idTarget)
{
    if(fileValue != '') {
        byId(idTarget).innerHTML = fileValue;
    }
}