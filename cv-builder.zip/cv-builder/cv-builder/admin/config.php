<?php
    // BDD PREPROD
    $hot = "server_name";
    $bdd = "database_name";
    $bddUser = "user_name";
    $bddMdp = "password";

    $emailAdmn = "your-email@gmail.com"; // Email adress used to send the hyperlink for password recovery.
    $siteValidation = "http://your-domain-name"; // Here, you porive the domain name of your website, and is used to recover the user password.

    // Database connection
    try
    {
        $bdd = new PDO("mysql:host=$hot;dbname=$bdd; charset=UTF8", $bddUser, $bddMdp);

        $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e)
    {
        echo "Erreur de connexion avec BDD : " . $e->getMessage();
    }

    // To set Time zone. (visit: https://www.php.net/manual/fr/timezones.php)
    date_default_timezone_set("Europe/Paris");