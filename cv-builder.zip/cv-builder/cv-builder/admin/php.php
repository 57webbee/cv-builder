<?php
session_start();

include("config.php");
include("lang.php");
include("e-mailer.php");
include("vignette.php");
include("upload-files.php");

// --------------------- Fonctions utiles. ---------------------
// Fonction pour filtrer les données envoyé avec $_GET et $_POST.
function filtre($donn)
{
    $donn = trim($donn);
    $donn = stripslashes($donn);
    $donn = htmlspecialchars($donn);
    return $donn;
}

// Hacher un mot de passe avec password_hash() et PASSWORD_DEFAULT
function hacherMDP($mdp)
{
    $mdpHach = password_hash($mdp, PASSWORD_DEFAULT);
    if(password_verify($mdp, $mdpHach))
    {
        return $mdpHach;
    }
}

$tabBase =
[
    "profil_img" =>
    [
        "src" => "",
    ],

    "cv_title" =>
    [
        "title-title-edit" => "",
        "name-edit" => "",
        "title-edit" => "",
        "field" => "cv_title",
    ],

    "summary" =>
    [
        "title-summary-edit" => "",
        "menu-summary" => "",
        "summary-edit" => "",
        "field" => "summary",
    ],

    "profil_field" =>
    [
        "title-profil_field" => "",
        "menu-profil_field" => "",
        "field" => "profil_field",
    ],

    "fields" =>
    [
        "exp_field" =>
        [
            "type" => "exp_field",
            "menu-text" => "",
            "title" => "",
            "img" => "img/list-style.jpg",
            "all-skills" =>
            [
                /* 0 =>
                [
                    "skill-name" => "Web developer",
                    "skill-details" => "Some text about web developer",
                ],
                1 =>
                [
                    "skill-name" => "Web Design",
                    "skill-details" => "Some text about web design",
                ], */
            ],
        ],

        "prog_field" =>
        [
            "type" => "prog_field",
            "menu-text" => "",
            "title" => "",
            "all-languages" =>
            [
                /* 0 =>
                [
                    "language-name" => "English",
                    "language-level" => 70,
                ], */
            ],
        ],

        "img_field" =>
        [
            "type" => "img_field",
            "menu-text" => "",
            "title" => "",
            "all-hobbies" =>
            [
                /* 0 =>
                [
                    "hobby-name" => "Bike",
                    "hobby-image" => "img/faire du vélo.png",
                ],
                1 =>
                [
                    "hobby-name" => "Photography",
                    "hobby-image" => "img/Photographie.png",
                ], */
            ],
        ],

        "hyper_field" =>
        [
            "type" => "hyper_field",
            "menu-text" => "",
            "title" => "",
            "all-projects" =>
            [
                /* 0 =>
                [
                    "project-image" => "source of the image",
                    "project-name" => "Blog",
                    "project-hyperlink" => "https://57webbee.com",
                    "project-hyperlink-name" => "Cliquez ici",
                ], */
            ],
        ],
    ],

    "social_net" =>
    [
        "social-networks" => "",
        "field" => "social_net",
    ],

    "update_date" =>
    [
        "date-label" => "",
        "date" => "",
        "field" => "update_date",
    ],
];

// Function to save default date.
function defaultDate($language, $bdd)
{
    // $date = date('d/m/Y H:i:s');
    $date = date('d/m/Y');

    // getting the date from database, which is in the json format.
    $rqt = $bdd -> prepare('SELECT update_date FROM cv WHERE cv_language=?');
    $rqt -> execute([$language]);
    $dateDB = $rqt -> fetch(PDO::FETCH_ASSOC);

    // Converting the date from json to array, adding default date and then reconverting it to json.
    $dateDB = json_decode($dateDB["update_date"], true);
    $dateDB["date"] = $date;
    $dateDB = json_encode($dateDB);

    //  And now saving it back to database.
    $MAJ = $bdd->prepare('UPDATE cv SET update_date=? WHERE cv_language=?');
    $MAJ -> execute([$dateDB, $language]);
}

// ---------------- Changing the admin language ----------------
if(isset($_POST["admin-language"]))
{
    $_SESSION["admin-language"] = $_POST["admin-language"];

    echo 'ok';
}

// ---------------- Registering a new user ----------------
if(isset($_POST['ins']) && $_POST['ins'] == "ins-user")
{
    array_pop($_POST); // Removing $_POST["ins"]

    // We check if the user sent any empty information.
    foreach($_POST as $cls => $vls)
    {
        if(empty($vls))
        {
            die($tabText["all-field-req"]);
        }
    }

    // Unsing a foreach() loop, we remove white spaces at the start and at the end, slashes et converting html tag into text.
    $infos = [];
    foreach($_POST as $cls => $vls)
    {
        $infos[$cls] = filtre($vls);
    }

    // Variables declaration.
    $nom = $infos['nom'];
    $email = $infos['email'];
    $mdp = hacherMDP($infos['mdp']);

    $date = date('d/m/Y');

    // With the help of foreach() loop, we check the number of characters sent by user and we store this record in a table $ch.
    $ch = [];
    foreach($_POST as $cls => $vls)
    {
        $ch[$cls] = strlen($vls);
    }

    if($ch["nom"] > 30) { echo $tabText["nom-Characters"]; }
    elseif($ch["email"] > 50) { echo $tabText["email-Characters"]; }
    elseif($ch["emailRetype"] > 50) { echo $tabText["email-retype-Characters"]; }
    elseif($ch["mdp"] < 5 OR $ch["mdp"] > 50) { echo $tabText["password-Characters"]; }
    elseif($ch["mdpRetype"] < 5 OR $ch["mdpRetype"] > 50) { echo $tabText["password-retype-Characters"]; }

    elseif($_POST["email"] !== $_POST["emailRetype"]) { echo $tabText["email-likewise"]; }
    elseif($_POST["mdp"] !== $_POST["mdpRetype"]) { echo $tabText["password-likewise"]; }

    elseif(filter_var($email, FILTER_VALIDATE_EMAIL) === false)
    {
        echo $tabText["email-validation"];
    }
    else
    {
        // Checking the user data in the database.
        $rqtTemp = $bdd -> prepare('SELECT * FROM login WHERE email=?');
        $rqtTemp -> execute([$email]);

        if($rqtTemp-> rowCount() != 0)
        {
            echo $tabText["email-exists"];
        }
        else
        {
            $inserer_membre = $bdd->prepare('INSERT INTO login(name, email, password) VALUES(?, ?, ?)');
            $ins = $inserer_membre -> execute([$nom, $email, $mdp]);

            if($ins)
            {
                session_unset();

                $_SESSION["nom"] = $nom;
                $_SESSION["email"] = $email;

                echo "done";
            }
        }
    }
}

// ---------------- Connecting a user ----------------
if(isset($_POST['conn']) && $_POST['conn'] == "conn-user")
{
    array_pop($_POST); // Removing $_POST["conn"]

    // Variables declaration.
    $email = filtre($_POST['email']);
    $mdp = filtre($_POST['mdp']);

    if(empty($email))
    {
        echo $tabText["email-empty"];
    }
    elseif(empty($mdp))
    {
        echo $tabText["password-empty"];
    }
    else
    {
        // Checking the user data in the database.
        $rqt = $bdd -> prepare('SELECT * FROM login WHERE email=?');
        $rqt -> execute([$email]);
        $rqtFtch = $rqt -> fetch(PDO::FETCH_ASSOC);

        if($rqtFtch["email"] != $email)
        {
            echo $tabText["email-not-found"];
        }
        elseif(!password_verify($mdp, $rqtFtch["password"]))
        {
            echo $tabText["password-erreur"];
        }
        else
        {
            session_unset();

            $_SESSION["nom"] = $rqtFtch["name"];
            $_SESSION["email"] = $rqtFtch["email"];

            echo "done";
        }
    }
}

// ---------------- Password recovery ----------------
if(isset($_POST['pswd']) && $_POST['pswd'] == "password-recovery")
{
    array_pop($_POST); // Removing $_POST["pswd"]

    // Variables declaration.
    $email = filtre($_POST['email']);
    $code = substr(str_shuffle(md5(bin2hex(random_bytes(100)))), 2);

    if(empty($email))
    {
        echo $tabText["email-empty"];
    }
    elseif(strlen($email) > 50)
    {
        echo $tabText["email-Characters"];
    }
    elseif(filter_var($email, FILTER_VALIDATE_EMAIL) === false)
    {
        echo $tabText["email-validation"];
    }
    else
    {
        // Checking the user data in the database.
        $rqt = $bdd -> prepare('SELECT * FROM login WHERE email=?');
        $rqt -> execute([$email]);
        $rqtFtch = $rqt -> fetch(PDO::FETCH_ASSOC);

        if($rqtFtch["email"] != $email)
        {
            echo $tabText["email-not-found"];
        }
        else
        {
            $url = $siteValidation.'/admin/pswd-recovery.php?name='.$rqtFtch["name"].'&code='.$code;

            $exped = $emailAdmn;
            $desti = $email;
            $subject = $tabText['pswd-recovery'];
            /* $body = '
            <!doctype html>
            <html>
            <head>
            <meta charset="utf-8">
            </head>
            <body>
            <h2>'.$tabText['reg-new-pswd'].' <strong>'.$email.'</strong></h2><br>
            <p>'.$tabText['hello'].' '.$rqtFtch["name"].' </p>
            <br>
            <p>'.$tabText['use-this-url'].'</p>
            <a href="'.$url.'" style="color: blue;">'.$url.'</a><br><br>
            <br>
            <hr width="100%" align="left">
            <hr width="100%" align="left">
            </body>
            </html>'; */

            // The file having the body of the mail.
            include('mail-mdp.php');

            // Registering the code in the database
            $MAJ = $bdd->prepare('UPDATE login SET code=? WHERE email=?');
            $ins = $MAJ -> execute([$code, $email]);

            if($ins)
            {
                /* $mailer = new eMailer;
                $mailer -> mailer($exped, $desti, $subject, $body); */

                $entete[] = 'MIME-Version: 1.0';
                $entete[] = 'Content-type: text/html; charset=uft-8';
                $entete[] = 'From: CV-Builder<'.$exped.'>';
                // $entete[] = 'To: CV-Builder<'.$desti.'>';

                mail($desti, $subject, $body,  implode("\r\n", $entete));

                echo "done";
            }
        }
    }
}
elseif(isset($_POST['pswd']) && $_POST['pswd'] == "registering-new-password")
{
    array_pop($_POST); // Removing $_POST["conn"]

    // Variables declaration.
    $mdp = filtre($_POST['mdp']);
    $mdpRetype = filtre($_POST['mdpRetype']);

    if(empty($mdp) OR empty($mdpRetype))
    {
        echo $tabText["all-field-req"];
    }
    elseif($mdp !== $mdpRetype)
    {
        echo $tabText["password-likewise"];
    }
    elseif(strlen($mdp) > 50 OR strlen($mdp) < 5)
    {
        echo $tabText["password-Characters"];
    }
    else
    {
        $mdp = hacherMDP($mdp);

        // Checking the user data in the database.
        $rqt = $bdd -> prepare('SELECT code FROM login WHERE code=?');
        $rqt -> execute([$_SESSION["code"]]);

        if($rqt -> rowCount() != 1)
        {
            echo $tabText["code-invalid"];
        }
        else
        {
            // Registering the new password in the database and deleting the code from the database.
            $MAJ = $bdd->prepare('UPDATE login SET password=?, code=? WHERE code=?');
            $ins = $MAJ -> execute([$mdp, null, $_SESSION["code"]]);

            if($ins)
            {
                session_unset();
                echo "done";
            }
        }
    }
}

// ---------------- Disconnecting a new user ----------------
// To logout a user.
if(isset($_POST["purpose"]) && $_POST["purpose"] == "deconnect-user")
{
    //session_unset();
    /* $_SESSION["nom"] = $rqtFtch["name"];
    $_SESSION["email"] = $rqtFtch["email"]; */

    unset($_SESSION['nom']);
    unset($_SESSION['email']);
    echo "disconnect";
}

// ---------------- Deleting the profil image ----------------
// To delete the profil image.
if(isset($_POST["purpose"]) && $_POST["purpose"] == "delete-image")
{
    $src = "img/img-profil/".basename($_POST["src"]);
    $language = $_POST["language"];

    $data  = ["src" => ""];
    $data  = json_encode($data);

    // Mofifying the data in the database.
    $MAJ = $bdd->prepare('UPDATE cv SET profil_img=? WHERE cv_language=?');
    $ins = $MAJ -> execute([$data, $language]);

    if($ins)
    {
        unlink($src);
        defaultDate($language, $bdd);
    }
}

// ---------------- Default language ----------------
// To choice a default language on loading.
if(isset($_POST["choice-lang-default"]) && $_POST["choice-lang-default"] == "to-choice-lang-default")
{
    // To get all the languages from database.
    $rqt = $bdd -> query('SELECT cv_language FROM cv');

    $langs = [];
    while($lang = $rqt -> fetch(PDO::FETCH_ASSOC))
    {
        array_push($langs, $lang["cv_language"]);
    }

    echo json_encode($langs);
}

// ---------------- Adding new language ----------------
// Add new language.
if(isset($_POST["new-language"]) && $_POST["new-language"] == "add-new-language")
{
    // Verification of the language existance in the database.
    $rqt = $bdd -> prepare('SELECT cv_language FROM cv WHERE cv_language=?');
    $rqt -> execute([$_POST["add-Language"]]);

    if($rqt -> rowCount() > 0)
    {
        echo $tabText["language-exist"];
    }
    else if($_POST["add-Language"] == $tabText['select-lang'])
    {
        echo $tabText["code-error"];
    }
    else
    {
        // Adding the new language in the database and creating new project of CV.

        // Saving all the fileds in a variable.
        $allFields = 'cv_language, profil_img, cv_title, summary, profil_field, fields, social_net, update_date';

        $allValues = [];
        array_push($allValues, $_POST["add-Language"]);

        foreach($tabBase as $vls)
        {
            array_push($allValues, json_encode($vls));
        }

        $MAJ = $bdd->prepare('INSERT INTO cv('.$allFields.') VALUES(?, ?, ?, ?, ?, ?, ?, ?)');
        $ins = $MAJ -> execute($allValues);

        if($ins)
        {
            // Now we get the list of all the lanuages once the asked language has been deleted.
            $rqt = $bdd -> query('SELECT cv_language FROM cv');

            $langs = [];
            while($lang = $rqt -> fetch(PDO::FETCH_ASSOC))
            {
                array_push($langs, $lang["cv_language"]);
            }

            $langs['message'] = "done";

            echo json_encode($langs);
        }
    }
}

// ---------------- Deleting a language ----------------
if(isset($_POST["delete-language"]) && $_POST["delete-language"] == "delete-this-language")
{
    // Verification of the language existance in the database.
    $rqt = $bdd -> prepare('SELECT cv_language FROM cv WHERE cv_language=?');
    $rqt -> execute([$_POST["current-language"]]);

    if($rqt -> rowCount() == 0)
    {
        echo $tabText["language-not-exist"];
    }
    else
    {
        $MAJ = $bdd->prepare('DELETE FROM cv WHERE  cv_language=?');
        $ins = $MAJ -> execute([$_POST["current-language"]]);

        if($ins)
        {
            // Now we get the list of all the lanuages once the asked language has been deleted.
            $rqt = $bdd -> query('SELECT cv_language FROM cv');

            $langs = [];
            while($lang = $rqt -> fetch(PDO::FETCH_ASSOC))
            {
                array_push($langs, $lang["cv_language"]);
            }

            $langs['message'] = "done";

            echo json_encode($langs);
        }
    }
}

// ---------------- Generated fields ----------------

/* Script to:
 * to add new generated fields in database
 * display all the data in the generated fields.
 * to delete an asked field from the database.
*/

 if(isset($_POST["purpose-field"]))
{
    $language = $_POST["language"];

    // getting the data from database, which is in the json format
    $rqt = $bdd -> prepare('SELECT fields FROM cv WHERE cv_language=?');
    $rqt -> execute([$language]);
    $fieldBDD = $rqt -> fetch(PDO::FETCH_ASSOC);

    $fieldBDD = $fieldBDD["fields"];

    // The following script is to add new field in database.
    if($_POST["purpose-field"] == "event")
    {
        $fieldBDD = json_decode($fieldBDD, true);

        // If the user submit the form without any <option> selected.
        if(!in_array($_POST["new-field"], ["exp_field", "prog_field", "img_field", "hyper_field",]))
        {
            exit($tabText['plz-select-a-field']);
        }

        // Generating the unique key for each filed with do{} while() loop
        do
        {
            $codeGn = date("YmdHis").rand(1, 100);
        }
        while(array_key_exists($codeGn, $fieldBDD));

        if(empty($fieldBDD))
        {
            $fieldBDD2[$codeGn] = $tabBase["fields"][$_POST["new-field"]];
        }
        else
        {
            $fieldBDD2 = [];
            foreach($fieldBDD as $cls => $vls)
            {
                // Script to add an elemnt in array before the first element.
                if($cls.(0) == $_POST["field-position"])
                {
                    $fieldBDD2[$codeGn] = $tabBase["fields"][$_POST["new-field"]];
                }

                $fieldBDD2[$cls] = $vls;

                // Script to add an elemnt in array after an element.
                if($cls == $_POST["field-position"])
                {
                    $fieldBDD2[$codeGn] = $tabBase["fields"][$_POST["new-field"]];
                }
            }
        }

        $fieldBDD2 = json_encode($fieldBDD2);

        $MAJ = $bdd->prepare('UPDATE cv SET fields=? WHERE cv_language=?');
        $MAJ = $MAJ -> execute([$fieldBDD2, $language]);

        if($MAJ)
        {
            defaultDate($language, $bdd);

            exit("done");
        }
    }

    // The following script is to display all the generated fields data.
    if($_POST["purpose-field"] == "display-generated-fields")
    {
        echo $fieldBDD;
    }

    // The following script is to delete an asked field from the database.
    else if($_POST["purpose-field"] == "delete-a-generated-field")
    {
        $fieldBDD = json_decode($fieldBDD, true);

        unset($fieldBDD[$_POST["id"]]);
        $fieldBDD = json_encode($fieldBDD);

        $MAJ = $bdd->prepare('UPDATE cv SET fields=? WHERE cv_language=?');
        $MAJ = $MAJ -> execute([$fieldBDD, $language]);

        if($MAJ)
        {
            defaultDate($language, $bdd);

            echo $_POST["id"];
        }
    }
}

// Script to update the generated fields data.
if(isset($_POST["add-field"]) && $_POST["add-field"] == "add-new-field")
{
    /* // Verification of the language existance in the database.
    $rqt = $bdd -> prepare('SELECT fields FROM cv WHERE fields=?');
    $rqt -> execute([$_POST["add-field"]]);

    if($rqt -> rowCount() > 0)
    {
        echo $tabText["language-exist"];
    }
    else
    {
        // Adding the new language in the database and creating new project of CV.
        $MAJ = $bdd->prepare('INSERT INTO cv(cv_language) VALUES(?)');
        $ins = $MAJ -> execute([$_POST["add-Language"]]);

        if($ins)
        {
            echo "done";
        }
    } */

    /* echo "<pre>";
    print_r($tabBase["fields"]["exp_field"]);
    echo "</pre>"; */
}

// ---------------- Display cv-data ----------------

// To get all the data from the database and display to the visitor.
if(isset($_POST["lang-default"]))
{
    $language = $_POST["lang-default"];

    // To get all the languages from database.
    $rqt = $bdd -> prepare('SELECT * FROM cv WHERE cv_language=?');
    $rqt -> execute([$language]);
    $dataCV = $rqt -> fetch(PDO::FETCH_ASSOC);

    if($rqt -> rowCount() > 0)
    {
        $data = [];
        foreach($dataCV as $cls => $vls)
        {
            $data[$cls] = json_decode($vls, true);
        }

        echo json_encode($data);
    }
}

// ---------------- Updating cv-data ----------------
// To modify the data in the database.
if(isset($_POST["field"]))
{
    // Unsing a foreach() loop, we remove white spaces at the start and at the end, slashes et converting html tag into text.
    $infos = [];
    foreach($_POST as $cls => $vls)
    {
        $infos[$cls] = filtre($vls);
    }

    $_FILES['image']['name'] = $_POST['compressed_name'];

    // With the help of foreach() loop, we check the number of characters sent by user and we store this record in a table $ch.
    $ch = [];
    foreach($_POST as $cls => $vls)
    {
        $ch[$cls] = strlen($vls);
    }

    $field = $infos["field"];
    $language = $infos["language"];

    // Deleting field and language from the $infos table.
    /* array_pop($infos);
    array_pop($infos); */

    // Profil image uploading.
    $data = "";
    if($field == "profil_img")
    {
        if(empty($_FILES))
        {
            die($tabText['nothing-sent']);
        }

        // Files temporary names.
        $nomTemp = $_FILES["profil_img"]["tmp_name"];

        // files exact names.
        $nomExact = $_FILES["profil_img"]["name"];

        // Files sizes.
        $sizeKB = filesize($nomTemp);
        $sizeMB = round($sizeKB/1000000, 2, PHP_ROUND_HALF_UP); // Conversion d'octets en Mo

        // Entensions paths.
        $chemin = dirname($nomTemp);
        $chemin = $chemin."\\".$nomExact;

        // Extension
        $extenF = $_POST["image-extension"];

        // Generating files names in PHP.
        $nomGenere = $_POST['compressed-name'];

        // Validating files sizes sent by users
        if($sizeMB > 8.2)
        {
            exit($tabText["file-size"]);
        }

        // Validating files formats sent by users
        $extAutori = ["gif", "jpg", "png"];
        if(!in_array($extenF, $extAutori))
        {
            exit($tabText["file-format"]);
        }

        // Files uploading
        if(move_uploaded_file($nomTemp, "img/img-profil/".$nomGenere))
        {
            // Deletion of the old image once the new one has been uploaded.
            if(file_exists("img/img-profil/".basename($_POST["src"])))
            {
                unlink("img/img-profil/".basename($_POST["src"]));
            }

            $srcTab = [];
            $srcTab["src"] = "img/img-profil/".$nomGenere;

            $data = json_encode($srcTab);
        }
        else
        {
            exit($tabText['nothing-sent']);
        }
    }

    // Modifying cv owner name and his job title.
    if($field == "cv_title")
    {
        foreach($ch as $vls)
        {
            if($ch["title-title-edit"] > 20)
            {
                die($tabText["char-limit"]."20");
            }
            if($ch["title-edit"] > 60 OR $ch["name-edit"] > 60)
            {
                die($tabText["char-limit"]."60");
            }
        }

        $data = json_encode($infos);
    }

    // Modifying cv owner summary.
    if($field == "summary")
    {
        if($ch["menu-summary"] > 20 OR $ch["title-summary-edit"] > 20)
        {
            die($tabText["char-limit"]."20");
        }
        else if($ch["summary-edit"] > 1000)
        {
            die($tabText["char-limit"]."1000");
        }

        $data = json_encode($infos);
    }

    // Modifying profil_field.
    if($field == "profil_field")
    {
        // Removing some elements from the array to make it simple for looping.
        unset($infos['title']);
        unset($infos['menuText']);
        unset($infos['field']);
        unset($infos['language']);
        unset($infos['id']);

        // Count the total number of characters for profile_field using the foreach() loop.
        $count = 0;
        foreach($infos as $vls)
        {
            $count += strlen($vls);
        }

        if($count > 16000000)
        {
            die($tabText["char-limit"]."16000000");
        }

        $data = json_encode($infos);
    }

    // Modifying generated fields
    if(in_array($field, ["exp_field", "prog_field", "img_field", "hyper_field",]))
    {
        $id = $_POST["id"];
        $menuText = $_POST["menuText"];
        $title = $_POST["title"];

        // getting the date from database, which is in the json format and is used to find image sources.
        $rqt = $bdd -> prepare('SELECT fields FROM cv WHERE cv_language=?');
        $rqt -> execute([$language]);
        $fieldBDD = $rqt -> fetch(PDO::FETCH_ASSOC);

        $fieldBDD = json_decode($fieldBDD["fields"], true);

        if($field == "exp_field")
        {
            // Script for storing image source in $srcImg variable either from the data base in case of an empty $_FILES submit or from submitted $_FILES array.
            if(isset($_FILES["image"]["error"]) && $_FILES["image"]["error"] == 0)
            {
                $imgupload = imgUploading($_FILES, 8.2, ["gif", "jpg", "png"], [$tabText["file-empty"], $tabText["file-size"], $tabText["file-format"], $tabText["uploading-error"], ], false, "../images/list/ready/", 500, false);

                $dirName = $imgupload["source-folder"];
                $fileName = $imgupload["generated-name"];
                $extName = $imgupload["extension"];

                $srcImg = $dirName.$fileName.".".$extName;
            }
            else
            {
                $srcImg = $fieldBDD[$id]["img"];
            }

            // Removing some elements from the array to make it simple for looping.
            unset($infos['title']);
            unset($infos['menuText']);
            unset($infos['field']);
            unset($infos['language']);
            unset($infos['id']);
            unset($infos['image_extension']);
            unset($infos['compressed_name']);

            // Script for making a array of "all-skills"
            $allSkill = [];
            $tabTemp = [];
            $count = 0;
            foreach($infos as $vls)
            {
                if($count % 2 == 0)
                {
                    $tabTemp["skill-name"] = $vls;
                }
                else
                {
                    $tabTemp["skill-details"] = $vls;
                    array_push($allSkill, $tabTemp);
                }

                $count += 1;
            }

            // Saving this new data in the $fieldBDD array in order to save then in the data base.
            $fieldBDD[$id] =
            [
                "id" => $id,
                "type" => $field,
                "menu-text" => $menuText,
                "title" => $title,
                "img" => $srcImg,
                "all-skills" => $allSkill,
            ];

            $dataToJs = ["Taj", $fieldBDD[$id]];
            $dataToJs = json_encode($dataToJs);
        }
        else if($field == "prog_field")
        {

            // Removing some elements from the array to make it simple for looping.
            unset($infos['title']);
            unset($infos['menuText']);
            unset($infos['field']);
            unset($infos['language']);
            unset($infos['id']);

            /* print_r($_POST);
            print_r($infos); */

            // Script for making a array of "all-languages"
            $allLanguages = [];
            $tabTemp = [];
            $count = 0;
            foreach($infos as $vls)
            {
                if($count % 2 == 0)
                {
                    $tabTemp["language-name"] = $vls;
                }
                else
                {
                    $tabTemp["language-level"] = $vls;
                    array_push($allLanguages, $tabTemp);
                }

                $count += 1;
            }

            // Saving this new data in the $fieldBDD array in order to save then in the data base.
            $fieldBDD[$id] =
            [
                "id" => $id,
                "type" => $field,
                "menu-text" => $menuText,
                "title" => $title,
                "all-languages" => $allLanguages,
            ];

            $dataToJs = ["Taj", $fieldBDD[$id]];
            $dataToJs = json_encode($dataToJs);
        }
        else if($field == "img_field")
        {
            // Script for storing image source in $tabSrcImg array either from the data base in case of an empty $_FILES submit or from submitted $_FILES array.
            $tabSrcImg = [];
            $ct = 0;
            $varTemp = [];
            foreach($_FILES as $cls => $vls)
            {
                array_push($varTemp, $cls);

                if(isset($_FILES[$cls]["error"]) && $_FILES[$cls]["error"] == 0)
                {
                    // Storing the first element of $_FILES array in $file array in order to use in imgUploading() function.
                    $file = [];
                    $file[$cls] = $vls;

                    $imgupload = imgUploading($file, 8.2, ["gif", "jpg", "png"], [$tabText["file-empty"], $tabText["file-size"], $tabText["file-format"], $tabText["uploading-error"], ], false, "../images/hobbies/ready/", 500, false);

                    $dirName = $imgupload["source-folder"];
                    $fileName = $imgupload["generated-name"];
                    $extName = $imgupload["extension"];

                    $srcImg = $dirName.$fileName.".".$extName;
                }

                // if the visitor adds a new project without any image and an image is already downloaded, we choose this one in the database.
                else if(isset($fieldBDD[$id]["all-hobbies"][$ct]))
                {
                    $srcImg = $fieldBDD[$id]["all-hobbies"][$ct]["hobby-image"];
                }

                // if the visitor adds a new project without any image, and we don't have any image already uploaded, then we choose a default image.
                else
                {
                    $srcImg = "../images/default-field-img.jpg";
                }

                array_push($tabSrcImg, $srcImg);
                $ct += 1;
            }

            // Removing some elements from the array to make it simple for looping.
            unset($infos['title']);
            unset($infos['menuText']);
            unset($infos['field']);
            unset($infos['language']);
            unset($infos['id']);
            unset($infos['image_extension']);
            unset($infos['compressed_name']);

            // Script for making a array of "all-hobbies"
            $allHobbies = [];
            $tabTemp = [];
            $ct = 0;
            foreach($infos as $vls)
            {
                $tabTemp["hobby-image"] = $tabSrcImg[$ct];
                $tabTemp["hobby-name"] = $vls;

                array_push($allHobbies, $tabTemp);

                $ct += 1;
            }

            // Saving this new data in the $fieldBDD array in order to save then in the data base.
            $fieldBDD[$id] =
            [
                "id" => $id,
                "type" => $field,
                "menu-text" => $menuText,
                "title" => $title,
                "all-hobbies" => $allHobbies,
            ];

            $dataToJs = ["Taj", $fieldBDD[$id]];
            $dataToJs = json_encode($dataToJs);

        }
        else if($field == "hyper_field")
        {
            // Script for storing image source in $tabSrcImg array either from the data base in case of an empty $_FILES submit or from submitted $_FILES array.
            $tabSrcImg = [];
            $ct = 0;
            foreach($_FILES as $cls => $vls)
            {
                if(isset($_FILES[$cls]["error"]) && $_FILES[$cls]["error"] == 0)
                {
                    // Storing the first element of $_FILES array in $file array in order to use in imgUploading() function.
                    $file = [];
                    $file[$cls] = $vls;

                    $imgupload = imgUploading($file, 8.2, ["gif", "jpg", "png"], [$tabText["file-empty"], $tabText["file-size"], $tabText["file-format"], $tabText["uploading-error"], ], false, "../images/projects/ready/", 500, false);

                    $dirName = $imgupload["source-folder"];
                    $fileName = $imgupload["generated-name"];
                    $extName = $imgupload["extension"];

                    $srcImg = $dirName.$fileName.".".$extName;
                }

                // if the visitor adds a new project without any image and an image is already downloaded, we choose this one in the database.
                else if(isset($fieldBDD[$id]["all-projects"][$ct]))
                {
                    $srcImg = $fieldBDD[$id]["all-projects"][$ct]["project-image"];
                }

                // if the visitor adds a new project without any image, and we don't have any image already uploaded, then we choose a default image.
                else
                {
                    $srcImg = "../images/default-field-img.jpg";
                }

                array_push($tabSrcImg, $srcImg);
                $ct += 1;
            }

            // Removing some elements from the array to make it simple for looping.
            unset($infos['title']);
            unset($infos['menuText']);
            unset($infos['field']);
            unset($infos['language']);
            unset($infos['id']);
            unset($infos['image_extension']);
            unset($infos['compressed_name']);

            // Script for making an multidimensional array of every project data like project-name, project-hyperlink, project-hyperlink-name.
            $ct = 0;
            $limit = 2;
            $ctImg = 0;
            $ctCle = 0;
            $projetsTemp = [];
            $allProjects = [];

            $taj = "";
            foreach($infos as $vls)
            {
                if($ct <= $limit)
                {
                    if($ct == $ctCle)
                    {
                        $projetsTemp["project-name"] = $vls;
                        $taj .= "1 ";
                    }
                    else if($ct == $ctCle+1)
                    {
                        $projetsTemp["project-hyperlink"] = $vls;
                        $taj .= "2 ";
                    }
                    else if($ct == $ctCle+2)
                    {
                        $projetsTemp["project-hyperlink-name"] = $vls;
                        $taj .= "3 ";
                    }
                    else
                    {
                        $taj .= "4 ";
                    }
                }

                // If the limit is exceeded, we store the image source from $tabSrcImg in $projetsTemp array and then the $projetsTemp array in $allProjects array.
                if($ct >= $limit)
                {
                    $projetsTemp["project-image"] = $tabSrcImg[$ctImg];
                    array_push($allProjects, $projetsTemp);
                    $projetsTemp = [];
                    $limit += 3;
                    $ctImg += 1;

                    //$ctCle = 0;
                    $ctCle += 3;
                }

                $ct += 1;
            }

            // Saving this new data in the $fieldBDD array in order to save then in the data base.
            $fieldBDD[$id] =
            [
                "id" => $id,
                "type" => $field,
                "menu-text" => $menuText,
                "title" => $title,
                "all-projects" => $allProjects,
            ];

            $dataToJs = ["Taj", $fieldBDD[$id]];
            $dataToJs = json_encode($dataToJs);

        }

        $field = "fields";
        $data = json_encode($fieldBDD);

        // Mofifying the data in the database.
        $MAJ = $bdd->prepare('UPDATE cv SET '.$field.'=? WHERE cv_language=?');
        $ins = $MAJ -> execute([$data, $language]);

        // Saving the default date when changes are made in any field.
        if($ins)
        {
            defaultDate($language, $bdd);
        }

        exit($dataToJs);
    }

    // Adding new or modifying the social networks.
    if($field == "social_net")
    {
        // Removing some elements from the array to make it simple for looping.
        unset($infos['field']);
        unset($infos['language']);
        unset($infos['id']);

        // Count the total number of characters for profile_field using the foreach() loop.
        $count = 0;
        foreach($infos as $vls)
        {
            $count += strlen($vls);
        }

        if($count > 16000)
        {
            die($tabText["char-limit"]."16000");
        }

        $data = json_encode($infos);
    }

    // Updading date field.
    if($field == "update_date")
    {
        // Count the total number of characters for profile_field using the foreach() loop.
        if($ch["date-label"] > 30)
        {
            die($tabText["char-limit"]."30");
        }
        if($ch["date"] > 20)
        {
            die($tabText["char-limit"]."20");
        }
        if(empty($infos["date"]))
        {
            // $infos["date"] = date('d/m/Y H:i:s');
            $infos["date"] = date('d/m/Y');
        }

        $data = json_encode($infos);
    }

    // Mofifying the data in the database.
    $MAJ = $bdd->prepare('UPDATE cv SET '.$field.'=? WHERE cv_language=?');
    $ins = $MAJ -> execute([$data, $language]);

    // Saving the default date when changes are made in any field.
    if($ins)
    {
        if($field != "update_date")
        {
            defaultDate($language, $bdd);
        }

        echo "done";
    }
}