<?php
    session_start();

    // Script for connected user.
    if(!isset($_SESSION['nom']) AND !isset($_SESSION['email']))
    {
        header('Location: index.php');
    }

    include("head.php");


    // To get all the languages from database.
    $rqt = $bdd -> query('SELECT cv_language FROM cv');

    $langs = [];
    while($lang = $rqt -> fetch(PDO::FETCH_ASSOC))
    {
        array_push($langs, $lang["cv_language"]);
    }
?>

<body onload="displayLangs(); langs(); displayData(Recup('lang-default')); newOrDeleteField('display-generated-fields', 'all');">
	<main id="main" class="main-cv-admin">
		<header id="hdr" class="hdr">
			<nav id="nav" class="nav">
			</nav>
		</header>

		<section id="sctn" class="sctn">
			<article id="artlReg" class="artlReg">
                <div class="container border border-1 mt-3">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="container">

                               <?php /* ---------- title CV-Admin ---------- */ ?>
                                <div class="row">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <h2 class="text-center">CV-builder</h2>
                                    </div>
                                </div>

                                <div class="row mt-n4 mb-2">
                                    <div class="col-12 text-right">
                                        <span id="btn-config" title="Display the admin configuration">
                                        <button type="button" class="btn btn-outline-secondary btn-sm deconn float-sm-right mx-sm-2 mb-2 p-0 btn-admin-config shadow-none">
                                            <i class="fas fa-cogs"></i>
                                        </button>
                                        </span>
                                    </div>
                                </div>

                                <div id="details-config" class="row border border-1 border-secondary mb-3 p-3 collapse">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <h4 class="text-center">Admin configuration</h4>
                                    </div>
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-12 mb-1">
                                            <button type="submit" name="deconn" id="deconn" class="btn btn-secondary btn-sm col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 deconn float-sm-right mx-sm-2 mb-2" onclick="funcBtn(event, 'deconnect-user')">
                                                <i class="fas fa-power-off"></i>
                                            </button>

                                            <select id="admin-languages" class="custom-select custom-select-sm col-xl-1 col-lg-2 col-md-2 col-sm-3 col-12 float-sm-right mx-sm-2 mb-2" onchange="changeAdminLang(this.value)">
                                                <option value="FR">FR</option>
                                                <option value="EN">EN</option>
                                            </select>
                                            </div>
                                            <?php /* <p id="admin-alert" class="col-12 text-center mt-2">Help or alert text</p> */ ?>
                                        </div>
                                    </div>
                                </div>

                                <?php /* ---------- language and logout buttons ---------- */ ?>
                                <div class="row pt-3">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <button type="submit" class="btn btn-secondary btn-sm col-xl-2 col-lg-2 col-md-2 col-sm-3 col-12 deconn float-sm-right mx-sm-2 mb-2" data-toggle="modal" data-target="#add-lang-field"><?php echo $tabText['manage-language']; ?></button>

                                        <select id="languages" class="custom-select custom-select-sm col-xl-2 col-lg-2 col-md-2 col-sm-3 col-12 float-sm-right mx-sm-2 mb-2" onchange=" langModify(this.value)">
                                        <?php /* <option value="English" >English</option>
                                            <option value="Français" selected>Français</option> */ ?>
                                        </select>

                                        <button type="submit" class="btn btn-secondary btn-sm col-xl-1 col-lg-2 col-md-2 col-sm-3 col-12 deconn float-sm-right mx-sm-2 mb-2" data-toggle="modal" data-target="#add-field" onclick="newOrDeleteField('display-generated-fields', 'all')"><?php echo $tabText['add-a-field']; ?></button>

                                        <a href="../index.php" target="_new" class="custom-control text-center col-xl-2 col-lg-2 col-md-3 col-sm-4 col-12 float-sm-right mb-2 mb-md-0"><?php echo $tabText['visit-website']; ?></a>
                                    </div>
                                </div>

                                <?php /* Adding new language OR deleting a language */ ?>
                                <div class="modal fade" id="add-lang-field">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <?php /* Modal Header */ ?>
                                            <div class="modal-header">
                                                <h4 class="modal-title"><?php echo $tabText['manage-language']; ?></h4>
                                                <p><?php echo $tabText['add-remove-lang-info']; ?></p>

                                                <button type="button" class="close" data-dismiss="modal" onclick="refreshPage()">&times;</button>
                                            </div>

                                            <?php /* Modal body */ ?>
                                            <div class="modal-body">
                                                <form id="form-new-lang">
                                                    <select name="add-Language" id="add-Language" class="custom-select custom-select-sm col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 mx-2 mb-2" require></select><br>
                                                    <button type="submit" class="btn btn-secondary btn-sm col-xl-1 col-lg-1 col-md-1 col-sm-2 col-2 deconn mx-sm-2 mb-2" onclick="newLanguage(event)"><?php echo $tabText['add']; ?></button>
                                                    <p id="msg-lang"></p>
                                                </form>

                                                <form id="form-delete-lang">
                                                    <select name="delete-Language" id="delete-Language" class="custom-select custom-select-sm col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 mx-2 mb-2" require>
                                                            <option value="Select language" disabled="" selected="true"><?php echo $tabText['select-lang']; ?></option>
                                                        <?php
                                                            foreach($langs as $lang) {
                                                        ?>
                                                                <option value="<?php echo $lang; ?>"><?php echo $lang; ?></option>
                                                        <?php
                                                            }
                                                        ?>


                                                    </select><br>
                                                    <button type="submit" class="btn btn-secondary btn-sm col-xl-1 col-lg-1 col-md-1 col-sm-2 col-2 deconn mx-sm-2 mb-2" onclick="deleteLanguage(event)"><?php echo $tabText['delete']; ?></button>
                                                    <p id="msg-lang-delete"></p>
                                                </form>
                                            </div>

                                            <?php /* Modal footer */ ?>
                                            <?php /* <div class="modal-footer">
                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                            </div> */ ?>
                                        </div>
                                    </div>
                                </div>

                                <?php /* Adding new field */ ?>
                                <div class="modal fade" id="add-field">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <?php /* Modal Header */ ?>
                                            <div class="modal-header">
                                                <h4 class="modal-title"><?php echo $tabText['add-new-field']; ?></h4>
                                                <p><?php echo $tabText['add-fields-info']; ?></p>
                                                <button type="button" class="close" data-dismiss="modal" onclick="refreshPage()">&times;</button>
                                            </div>

                                            <?php /* Modal body */ ?>
                                            <div class="modal-body">
                                                <form id="form-new-field" required>
                                                    <select name="new-field" id="new-field" class="custom-select custom-select-sm col-xl-4 col-lg-6 col-md-6 col-sm-6 col-6 mx-2 mb-2">
                                                        <option value="0" id="fieldDefault" disabled selected="true"><?php echo $tabText['select-a-field']; ?></option>
                                                        <option value="exp_field" title="<?php echo $tabText['experience-field-helptext']; ?>"><?php echo $tabText['experience-field']; ?></option>
                                                        <option value="prog_field" title="<?php echo $tabText['progress-bar-helptext']; ?>"><?php echo $tabText['progress-bar-field']; ?></option>
                                                        <option value="img_field" title="<?php echo $tabText['image-field-helptext']; ?>"><?php echo $tabText['image-field']; ?></option>
                                                        <option value="hyper_field" title="<?php echo $tabText['hyperlink-field-helptext']; ?>"><?php echo $tabText['hyperlink-field']; ?></option>
                                                    </select>
                                                    <select name="field-position" id="field-position" class="custom-select custom-select-sm col-xl-4 col-lg-6 col-md-6 col-sm-6 col-6 mx-2 mb-2">
                                                        <?php /* <option value="" >Select the position...</option> */ ?>
                                                        <?php /* <option value="Before Progress-bar field" >Before Progress-bar field</option> */ ?>
                                                    </select>
                                                    <button type="submit" class="btn btn-secondary btn-sm col-xl-1 col-lg-1 col-md-1 col-sm-2 col-2 deconn mx-sm-2 mb-2" onclick="newOrDeleteField(event, 'form-new-field')"><?php echo $tabText['add']; ?></button>
                                                    <p id="msg-field" class="text-center mt-2"></p>
                                                </form>
                                            </div>

                                            <?php /* Modal footer */ ?>
                                            <?php /* <div class="modal-footer">
                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                            </div> */ ?>
                                        </div>
                                    </div>
                                </div>

                                <?php /* ---------- profil_img ---------- */ ?>
                                <div class="row bg-light shadow-sm border border-1 mb-3 p-3">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <h4 class="text-center"><?php echo $tabText['profile-image']; ?></h4>
                                    </div>

                                    <div class="container">
                                        <div class="row">
                                            <div id="profil_img-div" class="col-xl-2 col-lg-2 col-md-2 col-sm-3 col-5 mb-2">
                                                <?php /* <img src="img/cv-logo.png" alt="Profil image" id="profil-img" class="rounded-circle img-thumbnail"/> */ ?>
                                            </div>

                                            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12 mt-auto mb-3">
                                                <form id="form-profil-img">
                                                    <div class="overflow-hidden custom-file custom-select-sm">
                                                        <input type="file" name="profil_img" class="custom-file-input" id="profil-img-edit" title="<?php echo $tabText['format-image']; ?>" accept="image/*">
                                                        <label class="custom-file-label" for="profil-img"><?php echo $tabText['format-image']; ?></label>
                                                    </div>
                                                </form>
                                            </div>

                                            <div class="col-xl-6 col-lg-6 col-md-4 col-sm-3 col-6 mt-auto mb-1">
                                                <button type="submit" name="delete" id="delete" class="btn btn-secondary btn-sm col-xl-2 col-lg-2 col-md-5 col-sm-8 col-12 mx-2 mb-3 ml-auto shadow-none" onclick="funcBtn(event, 'delete-image')" title="<?php echo $tabText['delete']; ?>"><?php echo $tabText['delete']; ?></button>
                                            </div>

                                            <p id="msg-profil_img" class="text-center mt-3"></p>
                                        </div>
                                    </div>
                                </div>

                                <?php /* ---------- name and cv_title ---------- */ ?>
                                <div id="edit-title" class="row bg-light shadow-sm border border-1 mb-3 p-3">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <h4 id="title-title" class="text-center"></h4>
                                    </div>

                                    <div class="container">
                                        <div class="row">
                                            <div id="title" class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12">
                                                <?php /* <p>Taj</p>
                                                <p>Développeur web</p> */ ?>
                                            </div>

                                            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">
                                                <i class="all-buttons fas fa-edit fa-sm btn btn-outline-info" title="<?php echo $tabText['edit-this-field']; ?>" onclick="slideAnim('edit-title', 'edit-title-field')"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="edit-title-field" class="row bg-light shadow-sm border border-1 mb-3 p-3 collapse">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12">
                                                <form method="post" id="form-title">
                                                    <div class="form-groupe">
                                                        <input type="text" id="title-title-edit" name="title-title-edit" class="mb-2 form-control" value=""  placeholder="<?php echo $tabText['title']; ?>" />
                                                        <input type="text" id="name-edit" name="name-edit" class="mb-2 form-control" value=""  placeholder="<?php echo $tabText['name-lastname']; ?>" />
                                                        <input type="text" id="title-edit" name="title-edit" class="mb-2 form-control" value=""  placeholder="<?php echo $tabText['web-developer']; ?>" />
                                                    </div>
                                                </form>

                                                <p id="msg-title" class="text-center mt-3"></p>
                                            </div>

                                            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">
                                                <i class="all-buttons fas fa-save btn btn-outline-success" onclick="modifyData('cv_title', 'form-title', 'edit-title', 'edit-title-field', 'msg-title')" title="<?php echo $tabText['save']; ?>"></i>
                                                <i class="all-buttons fas fa-times-circle btn btn-outline-warning mt-sm-2"  onclick="slideAnim('edit-title', 'edit-title-field');" title="<?php echo $tabText['cancel']; ?>"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php /* ---------- summary ---------- */ ?>
                                <div id="edit-summary" class="row bg-light shadow-sm border border-1 mb-3 p-3">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <h4 id="summary-title" class="text-center"></h4>
                                    </div>

                                    <div class="container">
                                        <div class="row">
                                            <div id="summary" class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12">
                                                <?php /* <p>Summary in here</p> */ ?>
                                            </div>

                                            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">
                                                <i class="all-buttons fas fa-edit fa-sm btn btn-outline-info" title="<?php echo $tabText['edit-this-field']; ?>" onclick="slideAnim('edit-summary', 'edit-summary-field')"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="edit-summary-field" class="row bg-light shadow-sm border border-1 mb-3 p-3 collapse">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12">
                                                <form method="post" id="form-summary">
                                                    <div class="form-groupe">
                                                        <input type="text" id="title-summary-edit" name="title-summary-edit" class="mb-2 form-control" value=""  placeholder="<?php echo $tabText['summary']; ?>" />

                                                        <div class="input-group mb-2">
                                                            <div class="input-group-prepend">
                                                                <span class="input-group-text"><?php echo $tabText['menu-text']; ?></span>
                                                            </div>

                                                            <input type="text" id="menu-summary" name="menu-summary" class="form-control" value="" placeholder="<?php echo $tabText['summary-min']; ?>"/>
                                                        </div>

                                                        <textarea id="summary-edit" name="summary-edit" class="form-control col-xl-12" rows="4" placeholder="<?php echo $tabText['summary-text']; ?>" ></textarea>
                                                    </div>
                                                </form>

                                                <p id="msg-summary" class="text-center mt-3"></p>
                                            </div>

                                            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">
                                                <i class="all-buttons fas fa-save btn btn-outline-success" onclick="modifyData('summary', 'form-summary', 'edit-summary', 'edit-summary-field', 'msg-summary')" title="<?php echo $tabText['save']; ?>"></i>
                                                <i class="all-buttons fas fa-times-circle btn btn-outline-warning mt-sm-2"  onclick="slideAnim('edit-summary', 'edit-summary-field', 'edit-summary', 'edit-summary-field');" title="<?php echo $tabText['cancel']; ?>"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php /* ---------- profil_field ---------- */ ?>
                                <div id="edit-profil_field" class="row bg-light shadow-sm border border-1 mb-3 p-3">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <h4 id="title-profil_field" class="text-center"></h4>
                                    </div>

                                    <div class="container">
                                        <div class="row">
                                            <div id="profil_field" class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12">
                                            </div>

                                            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">
                                                <i class="all-buttons fas fa-edit fa-sm btn btn-outline-info" title="<?php echo $tabText['edit-this-field']; ?>" onclick="slideAnim('edit-profil_field', 'edit-profil_field-field')"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="edit-profil_field-field" class="row bg-light shadow-sm border border-1 mb-3 p-3 collapse">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12">
                                                <form method="post" id="form-profil-field">
                                                </form>

                                                <p id="msg-profil_field" class="text-center mt-3"></p>
                                            </div>

                                            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">
                                                <i class="all-buttons fas fa-save btn btn-outline-success" onclick="modifyData('profil_field', 'form-profil-field', 'edit-profil_field', 'edit-profil_field-field', 'msg-profil_field')" title="<?php echo $tabText['save']; ?>"></i>
                                                <i class="all-buttons fas fa-plus btn btn-outline-info mt-sm-2" onclick="addInputField('form-profil-field', 'profil_field')" title="<?php echo $tabText['add']; ?>"></i>
                                                <i class="all-buttons fas fa-times-circle btn btn-outline-warning mt-sm-2"  onclick="slideAnim('edit-profil_field', 'edit-profil_field-field');" title="<?php echo $tabText['cancel']; ?>"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php /* ---------- The generated fields ---------- */ ?>
                                <div id="generated-field">
                                </div>

                                <?php /* ---------- social_net ---------- */ ?>
                                <div id="edit-social_net" class="row bg-light shadow-sm border border-1 mb-3 p-3">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <h4 id="title-social_net" class="text-center"></h4>
                                    </div>

                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12 mb-3">
                                                <div class="row mb-3">
                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-sm-left text-center" id="social-network">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">
                                                <i class="all-buttons fas fa-edit fa-sm btn btn-outline-info" title="<?php echo $tabText['edit-this-field']; ?>" onclick="slideAnim('edit-social_net', 'edit-social_net-field')"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="edit-social_net-field" class="row bg-light shadow-sm border border-1 mb-3 p-3 collapse">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12">
                                                <form method="post" id="form-social-net">
                                                </form>

                                                <p id="msg-social_net" class="text-center mt-3"></p>
                                            </div>

                                            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">
                                                <i class="all-buttons fas fa-save btn btn-outline-success" onclick="modifyData('social_net', 'form-social-net', 'edit-social_net', 'edit-social_net-field', 'msg-social_net')" title="<?php echo $tabText['save']; ?>"></i>
                                                <i class="all-buttons fas fa-plus btn btn-outline-info mt-sm-2" onclick="addInputField('form-social-net', 'social_net')" title="<?php echo $tabText['add']; ?>"></i>
                                                <i class="all-buttons fas fa-times-circle btn btn-outline-warning mt-sm-2"  onclick="slideAnim('edit-social_net', 'edit-social_net-field');" title="<?php echo $tabText['cancel']; ?>"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php /* ---------- update_date ---------- */ ?>
                                <div id="edit-update_date" class="row bg-light shadow-sm border border-1 mb-3 p-3">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <h4 id="title-update_date" class="text-center"></h4>
                                    </div>

                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12">
                                                <div class="row">
                                                    <div id="update-date" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-sm-left text-center">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">
                                                <i class="all-buttons fas fa-edit fa-sm btn btn-outline-info" title="<?php echo $tabText['edit-this-field']; ?>" onclick="slideAnim('edit-update_date', 'edit-update_date-field')"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div id="edit-update_date-field" class="row bg-light shadow-sm border border-1 mb-3 p-3 collapse">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-11 col-lg-11 col-md-11 col-sm-10 col-12">
                                                <form method="post" id="form-update-date">
                                                    <div class="input-group mb-2">
                                                        <input type="text" id="date-label" name="date-label" class="form-control col-12" value="" placeholder="<?php echo $tabText['date-title']; ?>" />
                                                        <input type="text" id="date" name="date" class="form-control col-12 ml-3" value="" placeholder="<?php echo $tabText['date-exemple']; ?>" title="<?php echo $tabText['data-info-title']; ?>" />
                                                    </div>
                                                </form>

                                                <p id="msg-update_date" class="text-center mt-3"></p>
                                            </div>

                                            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-2 col-12 text-center">
                                                <i class="all-buttons fas fa-save btn btn-outline-success" onclick="modifyData('update_date', 'form-update-date', 'edit-update_date', 'edit-update_date-field', 'msg-update_date')" title="<?php echo $tabText['save']; ?>"></i>
                                                <i class="all-buttons fas fa-times-circle btn btn-outline-warning mt-sm-2"  onclick="slideAnim('edit-update_date', 'edit-update_date-field');" title="<?php echo $tabText['cancel']; ?>"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			</article>
		</section>

		<footer id="ftr" class="bg-info text-center pt-3 pb-1 mt-3 ftr">
            <p class="text-light">Designed by: <a href="https://57webbee.com" class="text-light">57webbee</a></p>
		</footer>
    </main>

<?php
include("foot.php");
?>