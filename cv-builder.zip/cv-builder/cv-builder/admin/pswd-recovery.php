<?php
session_start();
$_SESSION["code"] =  $_GET["code"];

include("config.php");
include("head.php");
?>

<body>
	<main id="main" class="main">
		<?php
			$forValidUrl ='
			<section id="sctn" class="sctn">
				<div class="container border border-1 my-4 py-4">
					<div class="row">
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 px-sm-5">
							<form method="post"  id="form" class="container">
								<div class="row mb-3">
									<fieldset class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 border border-1 py-3">
										<legend class="col-xl-3 col-lg-4 col-md-5 col-sm-6 col-10 text-center">'.$tabText['password-recovery'].'</legend>

										<div class="form-group mx-sm-5">
											<div class="input-group mb-3">
												<input type="password" name="mdp" id="mdp" class="form-control chmpTxt" placeholder="'.$tabText['password'].' *" required/>
												<div class="input-group-append">
												<button class="btn btn-outline-secondary btn-sm" title="'.$tabText['password-visibility'].'" type="button" data-count=0 id="btn1Visible" onclick="pssdVisibility(event, \'mdp\', \'btn1Visible\')"><i class="fas fa-eye-slash"></i></button>
												</div>
											</div>

											<div class="input-group mb-3">
												<input type="password" name="mdpRetype" id="mdpRetype" class="form-control chmpTxt" placeholder="'.$tabText['retype-password'].' *" required/>
												<div class="input-group-append">
												<button class="btn btn-outline-secondary btn-sm" title="'.$tabText['password-visibility'].'" type="button" data-count=0 id="btn2Visible" onclick="pssdVisibility(event, \'mdpRetype\', \'btn2Visible\')"><i class="fas fa-eye-slash"></i></button>
												</div>
											</div>
										</div>
									</fieldset>
								</div>

								<div class="row">
									<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
										<button type="submit" id="btn" class="btn btn-secondary btn-sm" onclick="pswdSave(event)">'.$tabText['save'].'</button>
										<p id="msgPswd"></p>
									</div>
								</div>

								<div class="row">
									<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center">
										<a href="'.$siteValidation.'/admin/" title=""><span id="btnConn" class="all-buttons">'.$tabText['login'].'</span></a>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>

				<p id="msg"></p>
			</section>';

		$rqt = $bdd -> prepare('SELECT code FROM login WHERE code=?');
		$rqt -> execute([$_GET["code"]]);
		$rqtFtch = $rqt -> fetch(PDO::FETCH_ASSOC);

		if($rqtFtch["code"] != null && $rqtFtch["code"] != "")
		{
			echo $forValidUrl;
		}
		else
		{
			echo "Sorry, this URL has already been used.";
		}
		?>
    </main>

<?php
include("foot.php");
?>