<?php
final class eMailer
{
    public $nomExped = "";
    private $mailExped = "";
    public $nomDest = "";
    private $emailDest = "";
    private $sujet = "";
    private $corp = "";
    public $ccNom = "";
    public $ccEmail = "";
    //public $cciNom = ""; // Le nom et le mail de CCI est invisible sur l'email reçu, c’est pour cette raison que je l’ai enlevé.
    public $cciEmail = "";

    public function fEnv($mailExped, $emailDest, $sujet, $corp)
    {
        $this ->  mailExped = htmlspecialchars($mailExped);
        $this ->  emailDest = htmlspecialchars($emailDest);
        $this ->  sujet = htmlspecialchars($sujet);
        $this ->  corp = $corp;
        $entete[] = 'MIME-Version: 1.0';
        $entete[] = 'Content-type: text/html; charset=uft-8';

        $entete[] = 'To: '.$this -> nomDest.'<'.$this -> emailDest.'>';
        $entete[] = 'From: '.$this -> nomExped.'<'.$this -> mailExped.'>';
        if($this -> ccEmail != "")
        {
            if($this -> ccNom == "") { $entete[] = 'Cc: '.$this -> ccEmail; }
            if($this -> ccNom != "") { $entete[] = 'Cc: '.$this -> ccNom.'<'.$this -> ccEmail.'>'; }
        }
        if($this -> cciEmail != "")
        {
            $entete[] = 'Bcc: '.$this -> cciEmail;
            //if($this -> cciNom == "") { $entete[] = 'Bcc: '.$this -> cciEmail; }  // Le nom et le mail de CCI est invisible sur l'email reçu, c’est pour cette raison que je l’ai enlevé.
            //if($this -> cciNom != "") { $entete[] = 'Bcc: '.$this -> cciNom.'<'.$this -> cciEmail.'>'; }  // Le nom et le mail de CCI est invisible sur l'email reçu, c’est pour cette raison que je l’ai enlevé.
        }

        if(filter_var($this -> mailExped, FILTER_VALIDATE_EMAIL) === false)
        {
            echo "Erreur de paramètre-1 : L'adresse email de l'expéditeur n'est pas valide : ", $this -> mailExped, "<br>";
        }
        else if(filter_var($this -> emailDest, FILTER_VALIDATE_EMAIL) === false)
        {
            echo "Erreur de paramètre-2 : L'adresse email du destinataire n'est pas valide : ", $this -> emailDest, "<br>";
        }
        else if($this -> mailExped != "" AND $this -> emailDest != "" AND $this -> sujet != "" AND $this -> corp != "")
        {
            mail($this -> emailDest, $this -> sujet, $this -> corp,  implode("\r\n", $entete));
        }
    }

    public function mailer($mailExped1, $emailDest1, $sujet1, $corp1)
    {
        if(is_array($emailDest1))
        {
            for($i=0; $i<count($emailDest1); $i++)
            {
                $this -> fEnv($mailExped1, $emailDest1[$i], $sujet1, $corp1);
            }
        }
        else if(is_string($emailDest1))
        {
            $this -> fEnv($mailExped1, $emailDest1, $sujet1, $corp1);
        }
    }
}