<?php
	session_start();
	require_once('admin/config.php');

	// redirecting from HTTP to HTTPS
	/* if (
        !(isset($_SERVER['HTTPS']) &&
        ($_SERVER['HTTPS'] == 'on' ||
        $_SERVER['HTTPS'] == 1) ||
        isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
        $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')
    )
    {
        $redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        header('HTTP/1.1 301 Moved Permanently');
        header('Location: ' . $redirect);
        exit();
	}*/


    // Getting all the data from the database
	$langcurrent = $_SESSION['lang-default-frontend'];

	if($langcurrent == '') {
		$langcurrent = 'Français';
	}

    $rqt = $bdd->prepare('SELECT * FROM cv WHERE cv_language=?');
    $rqt -> execute([$langcurrent]);

    $databaseData = $rqt -> fetch(PDO::FETCH_ASSOC);

	// Definin variables for meta.
	$metaName = json_decode($databaseData['cv_title'], true)['name-edit'];
	$cvTitle = json_decode($databaseData['cv_title'], true)['title-edit'];
	$metaDes = json_decode($databaseData['summary'], true)['summary-edit'];

?>

<!doctype html>
<html lang="<?php echo $_SESSION['lang-code']; ?>">
<head>
	<meta charset="utf-8">
	<title id="page-title"><?php echo $metaName; ?> | <?php echo $cvTitle; ?></title>
	<link rel="icon" type="image/png" href="admin/img/cv-logo.png" />

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="<?php echo $metaDes; ?>" >
	<meta name="robots" content="INDEX,FOLLOW"/>
	<meta name="keywords" content="<?php echo $metaName; ?> | <?php echo $cvTitle; ?>" >
	<meta name="author" content="<?php echo $metaName; ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="style.css" type="text/css" media="all" >
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css?family=Dancing+Script&display=swap" rel="stylesheet">
	<script src="jQuery/jQuery.js" ></script>
    <script src="admin/all-langs.js"></script>
	<script src="js.js" ></script>
</head>

<body>
	<header class="header">

		<?php
		$nameTitle = json_decode($databaseData['cv_title'], true)['name-edit'];
		?>

		<h2 id="title"><?php echo $nameTitle; ?></h2>
		<h2 id="job-title"><?php echo $cvTitle; ?></h2>
		<a href="index.php">

		<?php

		$profImg = json_decode($databaseData['profil_img'], true);

			if($profImg['src'] == "")
			{
		?>

				<img src="admin/img/img-default.jpg" width="" height="" id="profile-image" alt="<?php echo $nameTitle; ?>"/>

		<?php
			}
			else
			{
		?>

				<img src="admin/<?php echo $profImg['src']; ?>" width="" height="" id="profile-image" alt="<?php echo $nameTitle; ?>"/>

		<?php
			}
		?>
		</a>
	</header>

	<?php /* <nav>
	  <ul id="left-menu">
		<!-- <a href="#résumé"><li class="menu_active">Résumé</li></a> -->
		<!-- <a href="#profil"><li>Profil</li></a>
		<a href="#competences"><li>Compétences</li></a>
		<a href="#experiences"><li>Experiences</li></a>
		<a href="#formations"><li>Formation</li></a>
		<a href="#langues"><li>Langues</li></a>
		<a href="#loisirs"><li>Loisirs</li></a>
		<a href="#contact"><li>Contact</li></a>
		<a href="#mesProj"><li>Mes projets</li></a> -->
	  </ul>
	</nav> */ ?>
	<section>
		<div class="div-lang">
			<select id="lang" class="" onchange="changeFrontendLang(this.value)">
			</select>
		</div>

		<?php
		$summaryText = json_decode($databaseData['summary'], true)['summary-edit'];
		$summaryTitle = json_decode($databaseData['summary'], true)['title-summary-edit'];

		if($summaryText != '') { ?>
			<h1 id="summary-h1"><?php echo $summaryTitle; ?></h1>
			<p id="summary-p"><?php echo $summaryText; ?></p>

			<br>
		<?php
		}
		?>



		<?php
		$profileText = json_decode($databaseData['profil_field'], true);

		if($profileText != '') { ?>

			<h1 id="profil"><?php echo $profileText['title-profil_field']; ?></h1>
			<div id="profile-conents">

			<?php

			$ct = 0;
			$elem1 = '';
			$elem2 = '';

			foreach($profileText as $cls => $vls) {

				if($ct > 1) {

					if($ct % 2 == 0) {

					$elem1 = $vls;
			?>

			<?php
					}
					else {

					$elem2 = $vls;
			?>

					<p><strong><?php echo $elem1; ?> </strong><?php echo $elem2; ?></p>

			<?php

					}

				}

			$ct += 1;
			}

			?>

	</div>
		<?php
		}
		?>

		<br>

	<div id="field">


		<?php

		$fields = json_decode($databaseData['fields'], true);

		foreach($fields as $cls => $vls) {

			/* ----------------------------------------- */
			/* ----------- Experience fields ----------- */
			/* ----------------------------------------- */

			if($vls['type'] == 'exp_field') {
		?>

			<h1><?php echo $vls['title']; ?></h1>
			<ul class="ul-skill-fields">

			<?php

				foreach($vls['all-skills'] as $skillVal) {
			?>
				<li>
					<img src="<?php echo $vls['img']; ?>" alt="<?php echo $vls['title']; ?> " class="skill-list-img">
					<h3><?php echo $skillVal['skill-name']; ?></h3>
					<p><?php echo str_replace('&quot;', '', str_replace('&gt;', '>', str_replace('&lt;', '<', $skillVal['skill-details']) )); ?></p>
				</li>

			<?php
				}
			?>

			</ul>

			<br>

		<?php
			}
			else if($vls['type'] == 'prog_field') {
		?>



		<?php
			/* ----------------------------------------- */
			/* ----------- Language fields ------------- */
			/* ----------------------------------------- */
		?>

		<h1><?php echo $vls['title']; ?></h1>
		<div class="langue" >

		<?php
			foreach($vls['all-languages'] as $langVls) {
		?>

			<div class="ligne" >
				<div class="textBar" ><?php echo $langVls['language-name']; ?></div>
				<div class="barLangue" ><meter max="100" value="<?php echo $langVls['language-level']; ?>" class="progress_anglais" ></meter></div>
			</div>

		<?php
			}
		?>

		</div>

		<br>



		<?php
			/* ----------------------------------------- */
			/* ------------- Image fields -------------- */
			/* ----------------------------------------- */
		?>

		<?php
			}

			else if($vls['type'] == 'img_field') {
		?>

		<h1><?php echo $vls['title']; ?></h1>
		<div>

		<?php
			foreach($vls['all-hobbies'] as $imgVal) {
		?>

			<div class="ligne" >
				<div class="divImg"><img src="<?php echo $imgVal['hobby-image']; ?>" alt="<?php echo $imgVal['hobby-name']; ?>" class="imgComtact"></div>
				<div class="textImg"><?php echo $imgVal['hobby-name']; ?></div>
			</div>

		<?php
			}
		?>

		</div>

		<?php

			}

			else if($vls['type'] == 'hyper_field') {
		?>

		<h1><?php echo $vls['title']; ?></h1>
		<div class="mesProjet">
		<div class="mesProjtsInn">

		<?php
			foreach($vls['all-projects'] as $hyperVal) {
		?>

			<div class="ligneProjts">
				<div class="mes_projets01">
					<img src="<?php echo $hyperVal['project-image']; ?>" alt="<?php echo $hyperVal['project-name']; ?>" width="50px">
				</div>

				<div class="mesPOuter">
					<div class="mes_projets03"><?php echo $hyperVal['project-name']; ?></div>
				</div>

				<div class="mes_projets02">
					<a href="<?php echo $hyperVal['project-hyperlink']; ?>">
						<p><?php echo $hyperVal['project-hyperlink-name']; ?></p>
					</a>
				</div>
			</div>

		<?php
			}
		?>

		</div>
		</div>

		<?php


			}

		}

		?>

	</div>

	</section>

	<?php
		$UpdateDate = json_decode($databaseData['update_date'], true);

		$SN = [
			"Facebook" => "fab fa-facebook-square text-primary ml-3 h3",
			"Blog" => "fas fa-blog text-danger ml-3 h3",
			"Twitter" => "fab fa-twitter-square text-primary ml-3 h3",
			"Linkedin" => "fab fa-linkedin text-primary ml-3 h3",
			"Viadeo" => "fab fa-viadeo-square text-danger ml-3 h3",
			"Instagram" => "fab fa-instagram text-danger ml-3 h3",
			"Snapshat" => "fab fa-snapchat-square text-warning ml-3 h3",
			"Google+" => "fab fa-google-plus-square text-danger ml-3 h3",
			"Pinterest" => "fab fa-pinterest-square text-danger ml-3 h3",
			"Tumblr" => "fab fa-tumblr-square text-info ml-3 h3",
			"Youtube" => "fab fa-youtube text-danger ml-3 h3",
			"Share" => "fas fa-share-alt text-info ml-3 h3",
			"Internet" => "fab fa-internet-explorer text-primary ml-3 h3",
		]
	?>

	<footer class="footer">
		<div class="footer-inner">
			<div class="reseau_sociaux" id="reseau_sociaux">

				<?php
				$socialNet = json_decode($databaseData['social_net'], true);

					unset($socialNet['social-networks']);
					unset($socialNet['field']);
					unset($socialNet['language']);
					unset($socialNet['id']);
					$elem1 = '';
					$elem2 = '';
					$ct = 1;

					foreach($socialNet as $vls)
					{

						if($ct % 2 == 1)
						{
							$elem2 = $SN[$vls];
						}
						else if($ct % 2 == 0)
						{
							?>

							<a href="<?php echo $vls; ?>" target="new">
								<div class="<?php echo $elem2; ?> social-net-icon"></div>
							</a>

							<?php
							$elem2 = '';
						}
						$ct += 1;
					}
				?>


				<?php /* <a href="https://www.facebook.com/57webbee/" target="new"><div class="fa fa-facebook-official fa-2x facebook_par_taj"></div></a>
				<a href="https://57webbee.com/" target="new"><div class="fa fa-2x fa-internet-explorer web_site_par_taj"></div></a> */ ?>
			</div>
			<div class="reseau_sociaux" id="update-date">
				<p><?php echo $UpdateDate['date-label']; ?> <?php echo $UpdateDate['date']; ?></p>
			</div>
		</div>
	</footer>
</body>
</html>
